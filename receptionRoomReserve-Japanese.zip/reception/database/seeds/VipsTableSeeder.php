<?php

use Illuminate\Database\Seeder;

class VipsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
          DB::table('vips')->insert([
              [
                  'name'            => 'nakazato',
                  'vip_id'          => 'vip0001',
                  'entry_date'      => '2015-10-15 23:59:59',
                  'renewal_date'    => '2015-10-15 23:59:59',
                  'expiration_date' => '2015-10-16 23:59:59',
                  'created_at'      => '2015-10-15 23:59:59',
                  'updated_at'      => '2015-10-15 23:59:59',
                  'valid'           => true,
              ],
              [
                  'name'            => 'Joshua',
                  'vip_id'          => 'vip0002',
                  'entry_date'      => '2015-10-15 23:59:59',
                  'renewal_date'    => '2015-10-15 23:59:59',
                  'expiration_date' => '2015-10-16 23:59:59',
                  'created_at'      => '2015-10-15 23:59:59',
                  'updated_at'      => '2015-10-15 23:59:59',
                  'valid'           => true,
              ],
              [
                  'name'            => 'Kuboyama',
                  'vip_id'          => 'vip0003',
                  'entry_date'      => '2015-10-15 23:59:59',
                  'renewal_date'    => '2015-10-15 23:59:59',
                  'expiration_date' => '2015-10-16 23:59:59',
                  'created_at'      => '2015-10-15 23:59:59',
                  'updated_at'      => '2015-10-15 23:59:59',
                  'valid'           => true,
              ],
          ]);

    }
}

