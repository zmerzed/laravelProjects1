<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
          DB::table('users')->insert([
              [
                  'name'          => 'nakazato',
                  'password'      => Hash::make('nakazato'),
                  'role'          => 'admin',
                  'created_at'    => '2015-10-15 23:59:59',
                  'updated_at'    => '2015-10-15 23:59:59',
                  'valid'         => true,
              ],
              [
                  'name'          => 'joshua',
                  'password'      => Hash::make('joshua'),
                  'role'          => 'staff',
                  'created_at'    => '2015-10-15 23:59:59',
                  'updated_at'    => '2015-10-15 23:59:59',
                  'valid'         => true,
              ],
              [
                  'name'          => 'kaz',
                  'password'      => Hash::make('kaz'),
                  'role'          => 'staff',
                  'created_at'    => '2015-10-15 23:59:59',
                  'updated_at'    => '2015-10-15 23:59:59',
                  'valid'         => true,
              ],
          ]);

    }
}
