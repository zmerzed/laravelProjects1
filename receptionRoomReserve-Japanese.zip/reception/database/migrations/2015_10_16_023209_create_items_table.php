<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('items', function (Blueprint $table) {
              $table->increments('id');
              $table->string('product_code');
              $table->string('name');
              $table->string('short_name');
              $table->integer('import_price');
              $table->integer('selling_price');
              $table->integer('stock');
              $table->dateTime('created_at');
              $table->dateTime('updated_at');
              $table->boolean('valid')->default(true);
          });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::drop('items');
    }
}
