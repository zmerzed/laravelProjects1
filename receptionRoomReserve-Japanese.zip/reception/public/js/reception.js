var RECEPTION = RECEPTION || {
    time: {},
    alert: {},
    print: {},
    loading: {},
    elapsedTime: {},
};

RECEPTION.time = (function(){ 

    setTime = function(selecter){
        Number.prototype.padLeft = function(base,chr){
            var  len = (String(base || 10).length - String(this).length)+1;
            return len > 0? new Array(len).join(chr || '0')+this : this;
        }

        var d = new Date(),
            dformat = [ d.getFullYear(),
                        (d.getMonth()+1).padLeft(),
                        d.getDate().padLeft()].join('/')+
                        ' ' +
                      [ d.getHours().padLeft(),
                        d.getMinutes().padLeft(),
                        d.getSeconds().padLeft()].join(':');

        $(selecter).text(dformat);
        return;
    }

    // public API
    return {
       setTime: setTime,
    };

}());

RECEPTION.alert = (function(){

    fadeOut = function(selecter){
        setTimeout(function() {
            $(selecter).fadeOut();
        }, 2000);
        return;
    };

    // public API
    return {
       fadeOut: fadeOut,
    };
}());

RECEPTION.print = (function(){

    // need bootbox.min.js 
    pdf = function(iframe,callback){
        dialog(iframe);
        var cnt = 0;
        var hoge = setInterval(function() {
            if (cnt < 1) {
                dialog(iframe);
            }else{
                bootbox.hideAll();
                clearInterval(hoge);
                if(callback){
                    callback();
                }
            }
            cnt++;
        }, 5000);
        return;
    };

    dialog = function(message){
        bootbox.dialog({
            title:'Print Receipt',
            message: message,
            button: {
                label: "Close",
            }
        });
    };

    // public API
    return {
       pdf: pdf,
    };
}());

RECEPTION.loading = (function(){

    // need jquery.blockUI.js  
    show = function(){
        bootbox.dialog({
            closeButton: false,
            size: "small", 
            message: "<div style='text-align:center'>Now loading</div>",
        });
        $('.bootbox').css({'margin':'15% auto auto',
                           'width':'300px'});
        
        return;
    };

    hide = function(){
        bootbox.hideAll();
    };

    // public API
    return {
       show: show,
       hide: hide,
    };
}());


RECEPTION.elapsedTime = (function(){
  var slip = {};
  clockStart();
  
  // run elapsedtime 
  function clockStart() { 
    setInterval(update, 1000);
    update();
  }
  
  function update() {
    
    slip.elapses = $('[id*=elapsed]');
    slip.test = $('[id*=test]');

    for (var i=0; i<slip.elapses.length; i++) 
    {
        var elapsed = document.getElementById(slip.elapses[i].id).innerHTML.split(" ");
        var hours = parseInt(elapsed[0]);
        var minutes = parseInt(elapsed[2]);
        var seconds = parseInt(elapsed[4]);
        var timeFormat = "";

        seconds++;

        if (seconds > 59) {
            seconds = 0;
            minutes++;
        }

        if (minutes > 59) {
            minutes = 0;
            hours++;
        }

        if (hours < 10) 
            hours = '0' + hours;

        if (minutes < 10) 
            minutes = '0' + minutes;

        if (seconds < 10) 
            seconds = '0' + seconds;
        
        timeFormat = hours + ' h ' + minutes + ' min ' + seconds + ' sec';
        document.getElementById(slip.elapses[i].id).innerHTML = timeFormat;
    }
  }
}());