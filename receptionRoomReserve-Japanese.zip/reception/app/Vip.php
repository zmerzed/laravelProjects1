<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vip extends Model
{
      /**
       * The table associated with the model.
       *
       * @var string
       */
      protected $table = 'vips';

      /**
       * The attributes that are mass assignable.
       *
       * @var array
       */
      protected $fillable = ['vip_id', 'name', 'entry_date', 'renewal_date', 'expiration_date'];
}
