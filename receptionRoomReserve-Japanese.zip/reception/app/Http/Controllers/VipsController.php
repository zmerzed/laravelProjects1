<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Carbon\Carbon;
use Auth;

use App\Http\Controllers\Controller;

use App\Vip;
use App\Http\Requests\VipCreatePostRequest;
use App\Http\Requests\VipEditPostRequest;
use App\Http\Requests\VipDeletePostRequest;

class VipsController extends Controller
{
    /**
      * @var Item
      */
     protected $vip;

     /**
      * @param Article $article
      */
     public function __construct(Vip $vip)
     {
        $this->middleware('auth');
        $this->vip = $vip;
     }

     public function getIndex(Request $request)
     {
     	$vips = $this->vip->where('valid', '=', true);
     	if(!empty($request->input('vip_id'))){
     		$vips->where('vip_id', '=', $request->input('vip_id'));
     	}
        $vips = $vips->get();
        return view('vips.index')->with(compact('vips'));
     }
     
     public function getCreateForm()
     {
     	return view('vips.createForm');
     }
     
     public function postCreate(VipCreatePostRequest $request)
     {
     	$this->vip->create($request->all())->save();
     	return redirect('/vips/list')->with('message', 'Create success');
     }
     
     public function getEditForm($id)
     {
     	$vip = $this->vip->find($id);
     	return view('vips.editForm')->with(compact('vip'));
     }
     
     public function postEdit(VipEditPostRequest $request)
     {
     	$vip = $this->vip->find($request->Input('id'));
     	$vip->update($request->all());
     	return redirect('/vips/list')->with('message', 'Update success');
     }
     
     public function getDeleteForm($id)
     {
     	$vip = $this->vip->find($id);
     	return view('vips.deleteForm')->with(compact('vip'));
     }
     
     public function postDelete(VipDeletePostRequest $request)
     {
     	$vip = $this->vip->find($request->Input('id'));
     	$vip->valid = false;
     	$vip->save();
     	return redirect('/vips/list')->with('message', 'Delete success');
     }
}


