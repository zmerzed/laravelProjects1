<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

use App\Slip;
use App\Http\Requests\CheckInPostRequest;
use App\Http\Requests\CheckOutPostRequest;

class SlipsController extends Controller
{
    /**
     * @var Item
     */
    protected $slip;

    /**
     * @param Article $article
     */
    public function __construct(Slip $slip)
    {
        $this->middleware('auth');
        $this->slip = $slip;
    }

    public function getIndex($term = "checkin")
    {
        $condition = array();
        if($term == "checkin"){
            $condition[] = array("check_out_date", "0000-00-00 00:00:00");
        }elseif($term == "checkout"){
            $condition[] = array("check_out_date", "!=", "0000-00-00 00:00:00");
        }
        
        $slips = $this->slip->searchWithPaginate($condition);
        
       
        
        return view('slips.index')->with(compact('slips'))
                                  ->with(compact('term'));
    }

    public function getPrint($id)
    {
        $pdfData['time'] = Carbon::now()->format('Y-m-d H:i:s'); 
        $pdfData['slip'] = $this->slip->searchById($id);
        $pdf = app('dompdf.wrapper');
        $pdf->setPaper('a7')->loadView('slips.print',compact('pdfData'));
        return $pdf->stream();
    }

    public function getCheckIn()
    {
        $checkedInAmenityIds = $this->slip->getCheckedInAmenityIds(); 
        return view('slips.checkin')->with(compact('checkedInAmenityIds'));
    }

    public function postCheckIn(CheckInPostRequest $request)
    {
        $data = $this->slip->setCheckInData($request->all());
        
        $insertId = $this->slip->create($data)->id;
        return redirect('slips/list')->with('message', 'Check In Success')
                                     ->with('checkInId', $insertId);
    }

    public function getCheckInPrint($id)
    {
        $pdfData['time'] = Carbon::now()->format('Y-m-d H:i:s'); 
        $pdfData['slip'] = $this->slip->searchById($id);
        $pdf = app('dompdf.wrapper');
      
        $pdf->setPaper('a7')->loadView('slips.checkinprint',compact('pdfData'));
        return $pdf->stream();
    }

    public function getCheckOut(Request $request)
    {
        // if the head of the slip_id is 480, exclude 480 and last letter. 
        if(preg_match("/^480([0-9]{9})[0-9]{1}$/", $request->input('slip_id'), $match)){
            $slip_id = $match[1]; 
        }else{
            $slip_id = $request->input('slip_id'); 
        }
        $slip = $this->slip->searchById($slip_id);
        return view('slips.checkout')->with(compact('slip'));
    }

    public function postCheckOut(CheckOutPostRequest $request)
    {
        $this->slip->checkOut($request->input('id'));
        return redirect('slips/list')->with('message', 'Check Out Success')
                                     ->with('checkOutId', $request->input('id'));
    }

}
