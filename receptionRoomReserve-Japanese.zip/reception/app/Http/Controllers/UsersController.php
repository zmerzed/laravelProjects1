<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\User;

class UsersController extends Controller
{
    /**
      * @var Item
      */
     protected $user;
  
     /**
      * @param Article $article
      */
     public function __construct(User $user)
     {
         $this->middleware('auth');
         $this->user = $user;
     }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getIndex()
    {
        //
        $users = $this->user->all();
        return view('users.index')->with(compact('users')); 
    }
}
