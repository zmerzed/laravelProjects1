<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Carbon\Carbon;
use Auth;

use App\Http\Controllers\Controller;

use App\Item;
use App\InventoryAdjustmentHistory;
use App\Http\Requests\InventoryPostRequest;
use App\Http\Requests\ItemCreatePostRequest;
use App\Http\Requests\ItemEditPostRequest;
use App\Http\Requests\ItemDeletePostRequest;

class ItemsController extends Controller
{
    /**
      * @var Item
      */
    protected $item;
  
     /**
      * @param Article $article
      */
    public function __construct(Item $item)
    {
        $this->middleware('auth');
        $this->middleware('authorize', ['except' => ['getItems', 'postItems']]);
        $this->item = $item;
        //var_dump(config('define.amenities'));
        //var_dump(config('define.charges'));
    }

    public function getIndex(Request $request)
    {
        $items = $this->item->where('valid', '=', true);
        if(!empty($request->input('product_code'))){
            $items->where('product_code', '=', $request->input('product_code'));
        }
        $items = $items->get();
        return view('items.index')->with(compact('items')); 
    }
  
    public function getItems()
    {
          $items = $this->item->where('valid', '=', true)->get();
          return view('items.items')->with(compact('items')); 
    }

    public function postItems(Request $request)
    {
        if (!empty($request->input('items'))) {
            $pdfData = array();
            $pdfData['time'] = Carbon::now()->format('Y-m-d H:i:s'); 
            $insertHistoryData = array();
            // update
            foreach ($request->input('items') as $value) {
                $item = $this->item->find($value['id']);
                $item->stock = $item->stock - $value['count']; 
                $item->save();
                $item->sold = $value['count'];
                $pdfData['items'][] = $item;
                $insertHistoryData[$value['id']]['sold'] = -$value['count']; 
            }
            InventoryAdjustmentHistory::insertMultipleData($insertHistoryData);
            // print pdf
            $pdf = app('dompdf.wrapper');
            $header = 50;
            $footer = 30;
            $height = $header + $footer + (count($pdfData['items']) * 17.25);
            if($height < 297.64){
                $height = 297.64;
            }
            $pdf->setPaper(array(0,0,209.76,$height));
            $pdf->loadView('items.print',compact('pdfData'));
            return base64_encode($pdf->stream());
        } 
        return redirect('/items');
    }

    public function getAdjustment()
    {
        $items = $this->item->where('valid', '=', true)->get();
        $reasons = config('define.adjustment_reasons'); 
        return view('items.adjustment')->with(compact('items'))
                                       ->with(compact('reasons')); 
    }

    public function postAdjustment(Request $request)
    {
        if ($request->input('items') != null) {
            // history insert and stock update
            InventoryAdjustmentHistory::insertMultipleData($request->input('items'));
            return "true";
        }
        return "false";
    }

    public function getCreateForm()
    {
        return view('items.createForm');
    }
  
    public function postCreate(ItemCreatePostRequest $request)
    {
        $this->item->create($request->all())->save();
        return redirect('/items/list')->with('message', 'Create success');
    }
  
    public function getEditForm($id)
    {
        $item = $this->item->find($id);
        return view('items.editForm')->with(compact('item'));
    }
  
    public function postEdit(ItemEditPostRequest $request)
    {
        $item = $this->item->find($request->Input('id'));
        $item->update($request->all());
        return redirect('/items/list')->with('message', 'Update success');
    }
  
    public function getDeleteForm($id)
    {
        $item = $this->item->find($id);
        return view('items.deleteForm')->with(compact('item'));
    }

    public function postDelete(ItemDeletePostRequest $request)
    {
        $item = $this->item->find($request->Input('id'));
        $item->valid = false;
        $item->save();
        return redirect('/items/list')->with('message', 'Delete success');
    }

    public function getInventory(Request $request)
    {
        $item = $this->item->where('valid', '=', true)
                           ->where('product_code', '=', $request->input('product_code'))
                           ->first();
        return view('items.inventory')->with(compact('item'));
    }

    public function postInventory(InventoryPostRequest $request)
    {
        $insertHistoryData[$request->input('id')]['inventory'] = 
            $request->input('adjustment_quantity');
        InventoryAdjustmentHistory::insertMultipleData($insertHistoryData);
        return redirect('items/inventory/?product_code='.$request->input('product_code'))
                   ->with('message', 'Update Success');
    }
}


