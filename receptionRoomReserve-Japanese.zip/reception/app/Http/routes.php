<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
// /
/*
Route::get('/', function () {
    return view('welcome');
});
*/

// Authentication routes...
Route::get('/', 'Auth\AuthController@getLogin');
Route::get('/auth/login', 'Auth\AuthController@getLogin');
Route::post('/auth/login', 'Auth\AuthController@postLogin');
Route::get('/auth/logout', 'Auth\AuthController@getLogout');
 
// Registration routes...
Route::get('/auth/register', 'Auth\AuthController@getRegister');
Route::post('/auth/register', 'Auth\AuthController@postRegister');
  
// /menu
Route::get('/menu', 'MenuController@getIndex');
//Route::controller('menu', 'MenuController');

// /items
Route::get('/items', 'ItemsController@getItems');
Route::post('/items/bill', 'ItemsController@postItems');
Route::get('/items/list', 'ItemsController@getIndex');
Route::get('/items/inventory', 'ItemsController@getInventory');
Route::post('/items/inventory', 'ItemsController@postInventory');
Route::get('/items/adjustment', 'ItemsController@getAdjustment');
Route::post('/items/adjustment', 'ItemsController@postAdjustment');
Route::get('/items/createform', 'ItemsController@getCreateForm');
Route::post('/items/create', 'ItemsController@postCreate');
Route::get('/items/editform/{id}', 'ItemsController@getEditForm');
Route::post('/items/edit', 'ItemsController@postEdit');
Route::get('/items/deleteform/{id}', 'ItemsController@getDeleteForm');
Route::post('/items/delete', 'ItemsController@postDelete');
//Route::controller('items', 'ItemsController');

// /slips
//Route::get('/slips/list', 'SlipsController@getIndex');
Route::get('/slips/list/{term?}', 'SlipsController@getIndex');
Route::get('/slips/checkIn', 'SlipsController@getCheckIn');
Route::post('/slips/checkIn', 'SlipsController@postCheckIn');
Route::get('/slips/checkInPrint/{id}', 'SlipsController@getCheckInPrint');
Route::get('/slips/checkOut', 'SlipsController@getCheckOut');
Route::post('/slips/checkOut', 'SlipsController@postCheckOut');
Route::get('/slips/print/{id}', 'SlipsController@getPrint');

// /users
Route::get('/users/list', 'UsersController@getIndex');

// /vips
Route::get('/vips/list', 'VipsController@getIndex');
Route::get('/vips/createform', 'VipsController@getCreateForm');
Route::post('/vips/create', 'VipsController@postCreate');
Route::get('/vips/editform/{id}', 'VipsController@getEditForm');
Route::post('/vips/edit', 'VipsController@postEdit');
Route::get('/vips/deleteform/{id}', 'VipsController@getDeleteForm');
Route::post('/vips/delete', 'VipsController@postDelete');

