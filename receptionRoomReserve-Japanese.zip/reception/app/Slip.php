<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use DB;

class Slip extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'slips';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['amenity_id', 'customer_id', 'check_in_date', 'check_out_date', 'charge'];

    protected static function getData($slips) {
        
    	return $slips->where('slips.valid', '1')->get();

    }
       
    protected static function getPaginateData($slips, $perPage = 15) {
        return $slips->where('slips.valid', '1')->paginate($perPage);
    }

    public static function search($conditions = array(), $pagenateFlag = false){
        $defaultCustomerId = config('define.default_customer_id');
        $amenities = config('define.amenities');

        $slips = DB::table('slips')
                 ->select(DB::raw('slips.id,slips.amenity_id,'.
                                  'CASE slips.customer_id '.
                                  'WHEN "'.$defaultCustomerId.'" '.
                                  'THEN slips.customer_id '.
                                  'ELSE vips.name END customer,'.
                                  'slips.check_in_date,slips.check_out_date'))
                 ->leftjoin('vips', 'vip_id', '=', 'slips.customer_id');
        if(count($conditions) > 0){
            foreach($conditions as $val){
                if(count($val) == 2){
                    $slips->where($val[0], $val[1]);
                }elseif(count($val) == 3){
                    $slips->where($val[0], $val[1], $val[2]);
                }
            }
        }

        $slips->orderBy('slips.id', 'desc');

        if($pagenateFlag){
            $slips = self::getPaginateData($slips);
        }else{
            $slips = self::getData($slips);
        }

        foreach($slips as $key => $data){
            $amenity = $amenities[$data->amenity_id-1];
            $slips[$key]->amenity = $amenity['amenity_name'];
            $slips[$key]->isCheckout = self::isCheckOut($data->check_out_date);
            $slips[$key]->elapsed = self::getElapsed($data->check_in_date, $data->check_out_date);
            $charge = self::getCharge($data->customer, $amenity['kind_of_amenity'], $data->check_in_date, $data->check_out_date);
            if($charge != null){
                $slips[$key]->charge = $charge["charge"];
                $slips[$key]->charge_code = $charge["code"];
            }else{
                $slips[$key]->charge = "not found";
                $slips[$key]->charge_code = "not found";
            }
        }
 
        return $slips;
    }

    public static function getElapsed($checkInDate, $checkOutDate){
        $checkInCarbon = Carbon::createFromFormat('Y-m-d H:i:s', $checkInDate);
        if($checkOutDate == "0000-00-00 00:00:00"){
            $checkOutCarbon = Carbon::now();
        }else{
            $checkOutCarbon = Carbon::createFromFormat('Y-m-d H:i:s', $checkOutDate);;
        }
        $interval = $checkOutCarbon->diff($checkInCarbon);
        $hourDiff = $checkOutCarbon->diffInHours($checkInCarbon);
        
        return $interval->format("{$hourDiff} h %I min %S sec"); // $interval->format('%H h %I min');
    }

    public static function isCheckout($checkOutDate) {
        if($checkOutDate == "0000-00-00 00:00:00") {
            return false;
        } else {
            return true;
        }
    }

    public static function getCharge($customer, $kindOfAmenity, $checkInDate, $checkOutDate){
        if($customer == config('define.default_customer_id')){
            $kindOfCustomer = config('define.default_customer_id');
        }else{
            $kindOfCustomer = 'vip';
        }

        $checkInCarbon = Carbon::createFromFormat('Y-m-d H:i:s', $checkInDate);
        if($checkOutDate == "0000-00-00 00:00:00"){
            $checkOutCarbon = Carbon::now();
        }else{
            $checkOutCarbon = Carbon::createFromFormat('Y-m-d H:i:s', $checkOutDate);
        }

        $interval = $checkOutCarbon->diff($checkInCarbon);
        $year = $interval->format('%y');
        $month = $interval->format('%m');
        $day = $interval->format('%d');
        $hours = $interval->format('%h');
        $minutes = $interval->format('%i');
        $seconds = $interval->format('%s');
        
        if (!empty($year) || !empty($month) || !empty($day)) {
            $time = 24;
        }else if($hours == 0){
            $time = 1;
        }else{
            $time = $hours;
            if($minutes > 0 || $seconds > 0){
                $time += 1;
            }
        }
        
        $charges = config('define.charges');
        foreach($charges as $charge){
            if($charge['customer'] == $kindOfCustomer &&
               $charge['kind_of_amenity'] == $kindOfAmenity &&
               $charge['time'] == $time){
                return $charge;
            }
        }
        return null;
    }

    public static function searchById($id) {
        $condition = array(array("slips.id",  $id));
        $searchData = self::search($condition);
        if(isset($searchData[0])){
            return $searchData[0];
        }
        return false;
    }

    public static function searchWithPaginate($condition = array()){
        return self::search($condition, true);
    }

    public static function setCheckInData($data) {
        if(empty($data['vip_id'])){
            $data['customer_id'] = config('define.default_customer_id');
        }else{
            $data['customer_id'] = $data['vip_id'];
        }
        $nowDate = Carbon::now();
        $data['check_in_date'] = $nowDate->toDateTimeString();
        return $data;
    }

    public static function checkOut($id) {
        $slip = self::find($id);
        $nowDate = Carbon::now();
        $slip->check_out_date = $nowDate->toDateTimeString();
        return $slip->save();
    }

    public static function getCheckedInAmenityIds() {
        $condition = array(array("check_out_date", "0000-00-00 00:00:00"));
        $usingAmenities = self::search($condition); 
        $checkedInAmenityIds = array();
        foreach($usingAmenities as $val){
            $checkedInAmenityIds[$val->amenity_id] = $val->amenity_id; 
        }
        return $checkedInAmenityIds;
    }

}
