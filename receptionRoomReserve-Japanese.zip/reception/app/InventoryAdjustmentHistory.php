<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Auth;

use App\Item;

class InventoryAdjustmentHistory extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'inventory_adjustment_histories';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['item_id', 'user_id', 'current_quantity', 'adjustment_quantity', 'adjustment_reason', 'adjustment_date'];

    public static function insertMultipleData($data) {
        $nowDate = Carbon::now();
        foreach($data as $itemId => $reasons){
            $item = Item::find($itemId);
            foreach($reasons as $reason => $quantity){
                $item->stock += $quantity;
                InventoryAdjustmentHistory::create(
                    ['item_id' => $itemId, 
                     'user_id' => Auth::user()->id,
                     'current_quantity' => $item->stock,
                     'adjustment_quantity' => $quantity,
                     'adjustment_reason' =>  config('define.adjustment_reasons')[$reason]['name'],
                     'adjustment_date' => $nowDate->toDateTimeString()] 
                )->save();
            }
            $item->save();
        }
    }
}
