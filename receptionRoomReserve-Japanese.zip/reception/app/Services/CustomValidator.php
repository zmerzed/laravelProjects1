<?php namespace App\Services;

use App\Slip;

class CustomValidator extends \Illuminate\Validation\Validator
{
    public function validateAmenityAuth($attribute,$value,$parameters){
        
        $amenities = config('define.amenities');
        $input = \Input::all();
        $kind_of_amenity = $amenities[$value-1]['kind_of_amenity'];
        if($kind_of_amenity == 'table'){
           return true;
        }elseif($kind_of_amenity == 'table2'){
           return true;
        }elseif($kind_of_amenity == 'vip room' && !empty($input['vip_id'])){
           return true;
        }
        return false;
    }

    public function validateAmenityAvailable($attribute,$value,$parameters){

        $conditions = array();
        $conditions[] = array("amenity_id", $value);
        $conditions[] = array("check_out_date", "0000-00-00 00:00:00");

        $slip = Slip::search($conditions);

        if(count($slip) == 0){
            return true;
        }
        return false;
    }

    public function validateSample($attribute,$value,$parameters){
        return $value == "sample";
    }

}
