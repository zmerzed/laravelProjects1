<div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">NEW</h4>
        </div>
        <div class="modal-body">
            <div class="row">
                <form class="form-items2" role="form" method="POST" action="/items/create">
                    {{-- CSRF対策--}}
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                    <div class="col-sm-4 col-sm-offset-1 label-pos"><label for="inputIname" class="sr-only_">ITEM NAME</label></div>
                    <div class="col-sm-6"><input type="text" id="inputIname" class="form-control" name="name" placeholder="" required autofocus></div>
                    <div class="col-sm-4 col-sm-offset-1 label-pos"><label for="inputSname" class="sr-only_">SHORT NAME</label></div>
                    <div class="col-sm-6"><input type="text" id="inputSname" class="form-control" name="short_name" placeholder="" required></div>
                    <div class="col-sm-4 col-sm-offset-1 label-pos"><label for="inputImport" class="sr-only_">IMPORT</label></div>
                    <div class="col-sm-6"><input type="text" id="inputImport" class="form-control" name="import_price" placeholder="" pattern="^[0-9]{1,}$" required></div>
                    <div class="col-sm-4 col-sm-offset-1 label-pos"><label for="inputSell" class="sr-only_">SELL</label></div>
                    <div class="col-sm-6"><input type="text" id="inputSell" class="form-control" name="selling_price" placeholder="" pattern="^[0-9]{1,}$" required></div>
                    <div class="col-sm-4 col-sm-offset-1 label-pos"><label for="inputCode" class="sr-only_">CODE</label></div>
                    <div class="col-sm-6"><input type="text" id="inputCode" class="form-control" name="product_code" placeholder="" required></div>
                    <div class="col-sm-12 col-xs-8 col-xs-offset-2">
                        <div class="row ptb15">
                            <div class="col-sm-6 col-sm-offset-3"><button class="btn btn-lg btn-primary btn-block item-btn-new" type="submit"><span>OK</span></button></div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
