<html>
<head>
<style>
@page { margin: 50px 50px 30px 50px; }
#header { position: fixed; left: 0px; top: -50px; right: 0px; height: 50px; font-weight: bold; font-size: 2em;}
#footer { position: fixed; left: 0px; bottom: -30px; right: 0px; height: 30px;}
table { width: 100%; }
</style>
</head>
<body style="text-align: center;">
<div id="header">
Blu cat
</div>
<div id="footer">
{{ $pdfData['time'] }}
</div>
<table>
@foreach($pdfData['items'] as $item)
<tr>
<td>{{ $item->name }}</td>
<td>{{ $item->sold }}</td>
</tr>
@endforeach
</table>
<script type="text/javascript">
  try {
    this.print();
  }
</script>
</body>
</html>
