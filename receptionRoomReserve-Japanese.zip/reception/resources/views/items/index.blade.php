@extends('master')
  @section('content')

<script type="text/javascript">
$(function(){
  $("#new").on('click', function () {
    $('#myModal').load("/items/createform",function(result){
      $('#myModal').modal('show');
    });
  });
  $('input[name=edit]').on('click', function () {
    var url = "/items/editform/" + $(this).data("n");
    $('#myModal').load(url,function(result){
      $('#myModal').modal('show');
    });
    return false;
  });
  $("input[name=delete]").on('click', function () {
    var url = "/items/deleteform/" + $(this).data("n");
    $('#myModal').load(url,function(result){
      $('#myModal').modal('show');
    });
    return false;
  });
});

$(window).load(function () {
    RECEPTION.alert.fadeOut(".alert-success");
});
</script>
@if (count($errors) > 0)
  <div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
    </ul>
  </div>
@endif
@if (session('message'))
  <div class="alert alert-success">
    {{ session('message') }}
  </div>
@endif
    <div class="row ptb15">
        <div class="col-sm-12 form-items2">
            <div class="row mtb15">
                <form method="GET" action="/items/list">
                    <div class="col-sm-3 label-pos"><label for="product_code" class="">PRODUCT CODE</label></div>
                    <div class="col-sm-4"><input type="text" id="product_code" class="form-control" placeholder="" name="product_code" value="{{ Input::get('product_code') }}"></div>
                    <div class="col-md-2">
                        <button id="search" class="btn btn-primary" style="margin-right: 15px;">SEARCH</button>
                    </div>
                </form>
                <div class="col-sm-3">
                    <button id="new" class="btn btn-lg btn-primary btn-block" type="button" data-toggle="modal" data-target='#myModal'><span>NEW</span></button>
                    <!-- Modal -->
                    <div id="myModal" class="modal fade" role="dialog">
                    </div>
                </div>
            </div>

            <div class="row mtb15 ptb15">
                <div class="col-sm-12 table-responsive">
                    <table class="table table-striped table-bordered check-table">
                        <thead>
                            <tr>
                                <th>Product Code</th>
                                <th>Name</th>
                                <th>Price</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($items as $item)
                            <tr>
                                <td>{{ $item->product_code }}</td>
                                <td>{{ $item->name }}</td>
                                <td>{{ $item->selling_price }}</td>
                                <td><input type="button" class="btn btn-default btn-primary" name="edit" value="Edit" data-n="{{ $item->id }}"><input type="button" class="btn btn-default" name="delete" value="Delete" data-n="{{ $item->id }}"></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
  @endsection
