@extends('master')
@section('content')

<script type="text/javascript">
$(function(){

  var items = {}; 

  // bind
  $(".reason button").on('click', function() {
    var objItem = $("input:radio[name='item']"); 
    if(!objItem.is(":checked")){
        bootbox.alert("Please select the item");
        return false;
    }
    var itemId = objItem.filter(":checked").data("n");
    var reasonId = this.id;
    if(itemId in items && reasonId in items[itemId]){
        items[itemId][reasonId]--;
        $("#" + itemId + "-" + reasonId).text(items[itemId][reasonId]);
    }else{
        var tagId = itemId + "-" + reasonId;
        var buttonTag = '<button data-item="' + itemId + '" data-reason="' + reasonId + '" type="button">+1</button>';
        var trTag = '<tr><td>' + objItem.filter(":checked").val() + '</td><td id="' + tagId + '">-1</td><td>' + this.name  + '</td><td>' + buttonTag + '</td></tr>';
        $('#target').append(trTag);
        if(!(itemId in items)){
            items[itemId] = {};
        }
        items[itemId][reasonId] = -1;
    }
  });

  // delegate
  $("#target").on('click', 'button', function() {
    var itemId = $(this).data("item");
    var reasonId = $(this).data("reason");
    items[itemId][reasonId]++;
    if(items[itemId][reasonId] == 0){
      this.closest('tr').remove();
      delete items[itemId][reasonId];
    }else{
      var tagId = itemId + "-" + reasonId;
      $("#" + tagId).text(items[itemId][reasonId]); 
    }
  });

  // submit pushing the button
  $("#billButton").on('click', function() {
    bootbox.confirm("Are you sure?", function(result) {
      if(result){
        $("#hiddenForm").submit();
      } 
    });
  });

  $("#hiddenForm").submit(function(e)
  {
    RECEPTION.loading.show();
    var formURL = $(this).attr("action");
    var token = $("[name='_token']").val();
    $.ajax({
      type : "POST",
      data : {"_token":token,"items":items},
      url : formURL,
      success : function(data) {
        RECEPTION.loading.hide();
        bootbox.alert("Adjustment Completed", function() {
          location.reload();
        });
      }
    });
    e.preventDefault(); //STOP default action
  });

});

$(window).load(function () {
    RECEPTION.alert.fadeOut(".alert-success");
});
</script>

<div id="loading" ></div>

    {{-- display a flash message --}}
    @if (Session::has('flashMessageItemsItems'))
    <div class="alert alert-success">{{ Session::get('flashMessageItemsItems') }}</div>
    @endif

    <div class="row page-items ptb15">
        <div class="col-sm-5">
            <div class="row items-buttons">
                <div class="col-sm-8 col-sm-offset-2">
                    <ul class="mtb15 items" data-toggle="buttons">
                        @foreach($items as $item)
                        <li class="btn btn-default">
                            <label><input data-n="{{ $item->id }}" type="radio" name="item" value="{{ $item->name }}">{{ $item->name }}</label>
                        </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="row adj-buttons reason">
                <div class="col-sm-10 col-sm-offset-1 adj-btn"><button class="btn btn-lg btn-primary btn-block" type="submit" id="damaged" name="{{ $reasons['damaged']['short_name'] }}"><span>{{ $reasons['damaged']['name'] }}</span></button></div>
                <div class="col-sm-10 col-sm-offset-1 adj-btn"><button class="btn btn-lg btn-primary btn-block" type="submit" id="0sales" name="{{ $reasons['0sales']['short_name'] }}"><span>{{ $reasons['0sales']['name'] }}</span></button></div>
                <div class="col-sm-10 col-sm-offset-1 adj-btn"><button class="btn btn-lg btn-primary btn-block" type="submit" id="lost" name="{{ $reasons['lost']['short_name'] }}"><span>{{ $reasons['lost']['name'] }}</span></button></div>
                <div class="col-sm-10 col-sm-offset-1 adj-btn"><button class="btn btn-lg btn-primary btn-block" type="submit" id="etc" name="{{ $reasons['etc']['short_name'] }}"><span>{{ $reasons['etc']['name'] }}</span></button></div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="row list-items">
                <div class="col-sm-10 col-sm-offset-1 table-responsive">
                    <table class="table check-table">
                        <tbody id="target">
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row bill-button mtb15 ptb15">
                <div class="col-sm-12">
                    <form id="hiddenForm" action="/items/adjustment" method="POST">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <button type="button" id="billButton" class="btn btn-lg btn-primary btn-block"><span>OK</span></button>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection
