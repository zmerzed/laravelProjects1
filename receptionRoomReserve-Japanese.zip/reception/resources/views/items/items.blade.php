@extends('master')
@section('content')

<script type="text/javascript">
$(function(){

  //var item = {id:null,count:null};  
  var items = []; 
  var searchItem = function(id) {
      var itemIndex = null;
      $.each(items,function(index, val){
        if(val.id == id) {
          itemIndex = index;
          return false; 
        }
      });
      return itemIndex; 
    };

  // bind
  $(".items button").on('click', function() {
    var index = searchItem(this.id); 
    if(index != null) {
      items[index].count++;
      $("#item" + items[index].id).text(items[index].count);
    }else{
      var item = {id:this.id,count:1};
      var buttonTag = '<button data-n="' + item.id + '" type="button">-1</button>';
      var trTag = '<tr><td>' + $(this).html() + '</td><td id="item' + item.id + '">1</td><td>' + buttonTag + '</td></tr>';
      $('#target').append(trTag);
      items.push(item);
    }
  });

  // delegate
  $("#target").on('click', 'button', function() {
    var index = searchItem($(this).data("n")); 
    items[index].count--;
    if(items[index].count == 0){
      this.closest('tr').remove();
      items.splice(index, 1);
    }else{
      $("#item" + items[index].id).text(items[index].count);  
    }
  });

  // submit pushing the button
  $("#billButton").on('click', function() {
    bootbox.confirm("Are you sure?", function(result) {
      if(result){
        $("#hiddenForm").submit();
      } 
    });
  });

  $("#hiddenForm").submit(function(e)
  {
    RECEPTION.loading.show();
    var formURL = $(this).attr("action");
    var token = $("[name='_token']").val();
    $.ajax({
      type : "POST",
      data : {"_token":token,"items":items},
      url : formURL,
      success : function(data) {
        RECEPTION.loading.hide();
        var iframe = '<object type="application/pdf" data="data:application/pdf;base64,' + data + '" width="100%" height="500px">No Support</object>'
        RECEPTION.print.pdf(iframe, function(){
            bootbox.alert("Bill Completed", function() {
                location.reload();
            });
        });
      }
    });
    e.preventDefault(); //STOP default action
  });
});
</script>


{{-- display a flash message --}}
@if (Session::has('flashMessageItemsItems'))
<div class="alert alert-success">{{ Session::get('flashMessageItemsItems') }}</div>
@endif

<div class="row page-items ptb15">
    <div class="col-sm-5">
        <div class="row items-buttons">
            <div class="col-sm-8 col-sm-offset-2">
                <ul class="mtb15 items" data-toggle="buttons">
                @foreach($items as $item)
                    <li><button class="btn btn-default" id="{{ $item->id }}">{{ $item->name }}</botton></li>
                @endforeach
                </ul>
            </div>
        </div>
    </div>
    <div class="col-sm-offset-2 col-sm-4">
        <div class="row list-items">
            <div class="col-sm-11 col-sm-offset-1 table-responsive mtb15">
                <table class="table check-table">
                   <tbody id="target">
                   </tbody>
                </table>
            </div>
        </div>
        <div class="row ptb15 mtb15">
            <div class="col-sm-12">
                <form class="form-items" id="hiddenForm" action="/items/bill" method="POST">
                   <input type="hidden" name="_token" value="{{ csrf_token() }}">
                   <button type="button" class="btn btn-lg btn-primary btn-block" id="billButton"><span>BILL</span></button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
