@extends('master')
@section('content')
<script type="text/javascript">
$(function(){
  $( "#add-stock" ).on('keyup change', function(e) {
    var addStock = parseInt($(this).val());
    var nowStock = parseInt($("#now-stock").val());
    if ( isNaN(addStock) ) {
        $("#new-stock").val(nowStock);
    } else {
        $("#new-stock").val(nowStock + addStock);
    }
  });
});

$(window).load(function () {
    RECEPTION.alert.fadeOut(".alert-success");
});
</script>

@if (count($errors) > 0)
  <div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
    </ul>
  </div>
@endif
@if (session('message'))
  <div class="alert alert-success">
    {{ session('message') }}
  </div>
@endif
<div class="row ptb15">
    <div class="col-sm-12">
        <form class="form-inventory" method="GET" action="/items/inventory">
            <div class="row">
                <div class="col-sm-3"><label for="inputPcode" class="sr-only_">PRODUCT CODE</label></div>
                <div class="col-sm-4"><input type="text" id="inputPcode" class="form-control" name="product_code" value="{{ Input::get("product_code") }}" placeholder="" required></div>
                <div class="col-md-1">
                    <button id="search" class="btn btn-primary" style="margin-right: 15px;">SEARCH</button>
                </div>
            </div>
        </form>
        @if (isset($item->id))
        <form class="form-inventory" method="POST" action="/items/inventory">
            <input type="hidden" name="_token" value="{{ csrf_token() }}">
            <input type="hidden" name="id" value="{{ $item->id }}">
            <input type="hidden" name="product_code" value="{{ $item->product_code }}">
            <div class="row mtb15 ptb15">
                <div class="col-sm-8 col-sm-offset-2">
                    <div class="row">
                        <div class="col-sm-6"><h4>{{ $item->name }}</h4></div>
                        <div class="col-sm-6">
                            <div class="row">
                                <div class="col-sm-5"><label for="now-stock" class="sr-only_">NOW</label></div>
                                <div class="col-sm-7"><input type="text" id="now-stock" class="form-control" value="{{ $item->stock }}" placeholder="" disabled></div>
                                <div class="col-sm-5"><label for="add-stock" class="sr-only_">ADD</label></div>
                                <div class="col-sm-7"><input type="number" id="add-stock" class="form-control" name="adjustment_quantity" value="0" placeholder="" required></div>
                                <div class="col-sm-5"><label for="new-stock" class="sr-only_">NEW</label></div>
                                <div class="col-sm-7"><input type="text" id="new-stock" class="form-control" value="{{ $item->stock }}" placeholder="" required readonly></div>
                                <div class="col-sm-12 mtb15">
                                    <button class="btn btn-lg btn-primary btn-block" type="submit"><span>SAVE</span></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        @endif
    </div>
</div>
@endsection
