@extends('master')
  @section('content')

<script type="text/javascript">
$(function(){
  $(window).load(function () {
    RECEPTION.time.setTime(".checkin-time"); 
    setInterval(function(){ RECEPTION.time.setTime(".checkin-time"); },1000); 
  });
  $('input:radio[name=amenity_id]').on('change', function() {  
    $('input:text[name=vip_id]').focus();
  });
});
</script>

@if (count($errors) > 0)
  <div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
    </ul>
  </div>
@endif
<div class="row">
    <div class="col-sm-12">
        <div class="checkin-time"></div>
    </div>
</div>

<div class="row">
    <div class="col-sm-8">
        <form class="form-checkin" method="POST" action="/slips/checkIn">
            {{-- CSRF対策--}}
            <input type="hidden" name="_token" value="{{ csrf_token() }}">
            <div class="row">
                <div class="col-sm-3"><label for="inputSlipId" class="mtb15">SLIP ID</label></div>
                <div class="col-sm-7"><input type="text" id="inputSlipId" class="form-control mtb15" name="slip_id" placeholder="" disabled></div>
            </div>
            <div class="row checkmenu-items mtb15 text-center">
                <div class="col-sm-12">
                    <div class="row">
                        <ul data-toggle="buttons">
                        @foreach(config("define.amenities") as $amenity)
                            <li @if (isset($checkedInAmenityIds[$amenity['amenity_id']])) disabled @endif class="col-sm-3 btn btn-default @if ($amenity['amenity_id'] == Input::old('amenity_id')) active @endif">
                                <label><input type="radio" name="amenity_id" value="{{ $amenity["amenity_id"] }}" @if ($amenity["amenity_id"] == Input::old("amenity_id")) checked @endif required />{{ $amenity["amenity_name"] }}</label>
                            </li>
                        @endforeach
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3"><label for="inputVipId" class="">VIP ID</label></div>
                <div class="col-sm-7"><input type="text" id="inputVipId" class="form-control" placeholder="" name="vip_id" value="{{ Input::old("vip_id") }}"></div>
            </div>
            <div class="row ptb15">
                <div class="col-sm-6">
                    <button class="btn btn-lg btn-primary btn-block" type="submit"><span>CHECK IN</span></button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
