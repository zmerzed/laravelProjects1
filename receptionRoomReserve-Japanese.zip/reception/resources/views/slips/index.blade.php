@extends('master')
  @section('content')
<script type="text/javascript">
function popupPdf(pdf_link){
  var iframe = '<object type="application/pdf" data="'+pdf_link+'" width="100%" height="500px">No Support</object>'
  RECEPTION.print.pdf(iframe);
  return;
}
$(function(){
  $('input[name=checkout]').on('click', function () {
    $(location).attr('href','/slips/checkOut/?slip_id=' + $(this).data('n')); 
    return false;
  });
});
$(function(){
  $('a[name=print]').on('click', function () {
    popupPdf('/slips/print/' + $(this).data('n')); 
    return false;
  });
  $('a[name=printcheckin]').on('click', function () {
	popupPdf('/slips/checkInPrint/' + $(this).data('n')); 
	return false; 
  });
});
$(window).load(function () {
  RECEPTION.elapsedTime;
  RECEPTION.alert.fadeOut('.alert-success');
  @if(session('checkOutId'))
    popupPdf('/slips/print/{{ session("checkOutId") }}');
  @endif
  @if(session('checkInId'))
    popupPdf('/slips/checkInPrint/{{ session("checkInId") }}');
  @endif
});
</script>
<div class="row ptb15">
    <div class="col-sm-12">
        <form class="form-slips">
            <div class="row ptb15">
                <div class="col-md-5 col-sm-6 col-xs-12">
                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-4">
                        @if ($term == 'checkin') 
                            <i class="fa fa-check-square-o"></i> Check-In
                        @else
                            <a href="/slips/list/checkin"><i class="fa fa-check-square-o"></i> Check-In</a>
                        @endif
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4">
                        @if ($term == 'checkout') 
                            <i class="fa fa-cart-plus"></i> Check-Out
                        @else
                            <a href="/slips/list/checkout"><i class="fa fa-cart-plus"></i> Check-Out</a>
                        @endif
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4">
                        @if ($term == 'all') 
                            <i class="fa fa-tags"></i> All
                        @else
                            <a href="/slips/list/all"><i class="fa fa-tags"></i> All</a>
                        @endif
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 table-responsive">
                    <table class="table table-striped table-bordered check-table">
                        <thead>
                            <tr>
                                <th>Slip id</th>
                                <th>Amenity</th>
                                <th>Customer</th>
                                <th>Entrance</th>
                                <th>Elapsed</th>
                                <th>Charge</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($slips as $slip)
                            <tr>
                                <td>{{ $slip->id }}</td>
                                <td>{{ $slip->amenity }}</td>
                                <td>{{ $slip->customer }}</td>
                                <td>{{ $slip->check_in_date }}</td>
                                <td id="@if(!$slip->isCheckout) elapsed{{ $slip->id }} @endif">@if(!$slip->isCheckout){{ $slip->elapsed }}@else {{ substr($slip->elapsed,0, -6)}}@endif</td>
                                <td>{{ $slip->charge }}</td>
                                <td><span><input type="button" class="btn btn-default" name="checkout" value="Checkout" data-n="{{ $slip->id }}" @if ($slip->check_out_date != "0000-00-00 00:00:00") disabled @endif ><a href="#" data-n="{{ $slip->id }}"  @if ($slip->check_out_date != "0000-00-00 00:00:00") name="print" @else name="printcheckin" @endif >Print</a></span></td>                          
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    {!! $slips->render() !!}
                </div>
            </div>
        </form>
    </div>
</div>

@endsection