<html>
<head>
<style>
@page { margin: 50px 50px 30px 50px; }
body{font-size: .9em;}
div.header { position: fixed; left: 0px; top: -50px; right: 0px; height: 50px; font-weight: bold; font-size: 2em;}
div.footer { position: fixed; left: 0px; bottom: -30px; right: 0px; height: 30px;}
table { width: 100%; }
</style>
</head>
<body>
<div class="header" style="text-align: center;">
Blu cat
</div>
<div class="footer" style="text-align: center;">
{{ $pdfData['time'] }}
</div>
<span style="font-weight: bold;font-size: 2em;">#{{ $pdfData['slip']->id }}</span>
<br />
<br />
{{ $pdfData['slip']->customer }}<br />
{{ $pdfData['slip']->amenity }}<br />
<br />
{{ $pdfData['slip']->charge }} PhP<br />
<br />
Check in<br />
{{ $pdfData['slip']->check_in_date }}<br />
<br />
Check out<br />
{{ $pdfData['slip']->check_out_date }}<br />
<br />
<?php echo DNS1D::getBarcodeHTML($pdfData['slip']->charge_code, 'EAN13',1.5) ?> 
<script type="text/javascript">
  try {
    this.print();
  } catch(exception){catchStatements
	  
  }
  finally {
      finallyStatements
  }
</script>
</body>
</html>
