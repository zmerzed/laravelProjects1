@extends('master')
@section('content')

<script type="text/javascript">
$(window).load(function () {
    RECEPTION.time.setTime(".checkin-time"); 
    setInterval(function(){ RECEPTION.time.setTime(".checkin-time"); },1000); 
});
</script>

@if (count($errors) > 0)
  <div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
    </ul>
  </div>
@endif
<div class="row">
    <div class="col-sm-12">
        <div class="checkin-time"></div>
    </div>
</div>

<div class="row">
    <div class="col-sm-12">
        <form class="form-checkout" method="GET" action="/slips/checkOut">
            <div class="row ptb15">
                <div class="col-sm-2"><label for="inputSlipId" class="">SLIP ID</label></div>
                <div class="col-sm-5"><input type="text" id="inputSlipId" class="form-control" name="slip_id" value="{{ Input::get('slip_id') }}" placeholder="" required autofocus></div>
                <div class="col-md-1">
                    <button id="search" class="btn btn-primary" style="margin-right: 15px;">SEARCH </button>
                </div>
            </div>
        </form>
        @if (isset($slip->id))
        <form class="form-checkout" method="POST" action="/slips/checkOut"> 
            <input type="hidden" name="_token" value="{{ csrf_token() }}">
            <input type="hidden" name="id" value="{{ $slip->id }}">
            <div class="row mtb15">
                <div class="col-sm-12 table-responsive">
                    <table class="table table-striped table-bordered check-table">
                        <thead>
                            <tr>
                                <th>Slip Id</th>
                                <th>Amenity</th>
                                <th>Customer</th>
                                <th>Entrance</th>
                                <th>Elapsed</th>
                                <th>Charge</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{{ $slip->id }}</td>
                                <td>{{ $slip->amenity }}</td>
                                <td>{{ $slip->customer }}</td>
                                <td>{{ $slip->check_in_date }}</td>
                                <td id="@if(!$slip->isCheckout) elapsed{{ $slip->id }} @endif">@if(!$slip->isCheckout){{ $slip->elapsed }}@else {{ substr($slip->elapsed,0, -6)}}@endif</td>
                                <td>{{ $slip->charge }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <button class="btn btn-lg btn-primary btn-block" type="submit"><span>CHECK OUT</span></button>
                </div>
            </div>
        </form>
        @endif
    </div>              
</div>
@endsection
