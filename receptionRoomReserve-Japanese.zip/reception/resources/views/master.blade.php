<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Reception System</title>
    <!-- Bootstrap -->
    <link href="/css/bootstrap.3.3.5.min.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->   
    <!-- Optional theme -->
    <link rel="stylesheet" href="/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <!-- Latest compiled and minified JavaScript -->    
    <script src="/js/jquery-1.11.3.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/respond.js"></script>
    <script src="/js/reception.js"></script>
    
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	
	<script src="/js/jquery-ui-timepicker-addon.min.js"></script>
	<link rel="stylesheet" href="/css/jquery-ui-timepicker-addon.min.css">
	<script src="/js/jquery-ui-sliderAccess.js"></script>
	<link rel="stylesheet" href="/cs/jquery-ui-timepicker-addon.css">
	<script src="/js/jquery-ui-timepicker-addon.js"></script>	
	<link rel="stylesheet" href="/css/style.css">	
  </head>
  <body>
    <div class="container-fluid page-head">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h1>{{config("define.system_name")}}</h1>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid page-wrapper">
        <div class="container">
            <div class="row acc-loggedin ptb15 mtb15">              
                <div class="col-sm-offset-7 col-sm-5 col-md-offset-8 col-md-4">
                    @if (Auth::user())
                    <div class="row">
                        <div class="col-xs-7"><span class="user-acc">{{Auth::user()->name}}</span></div>
                        @if (Request::is('menu'))
                            <a href="/auth/logout"><div class="col-xs-5"><span class="logout">Log-out</span></div></a>
                        @else
                            <a href="/menu"><div class="col-xs-4"><span class="menu-tab">Menu</span></div></a>
                        @endif
                    </div>
                    @endif
                </div>              
            </div>
            @yield('content')
        </div><!-- /container -->
    </div> 
    <div class="container-fluid page-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="text-center">{!!config("define.copy_right")!!} </div>
                </div>
            </div>
        </div>
    </div>
  </body>
</html>
