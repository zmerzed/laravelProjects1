@extends('master')
  @section('content')
      <h2 class="page-header">Users</h2>
      <p><a href="/auth/register" class="btn btn-primary" role="button">New</a></p>
      <table class="table table-striped table-hover">
          <thead>
          <tr>
              <th>id</th>
              <th>name</th>
              <th>role</th>
              <th>created at</th>
          </tr>
          </thead>
          <tbody>
          @foreach($users as $user)
              <tr>
                   <td>{{ $user->id }}</td>
                   <td>{{ $user->name }}</td>
                   <td>{{ $user->role }}</td>
                   <td>{{ $user->created_at }}</td>
              </tr>
          @endforeach
          </tbody>
      </table>
  @endsection
