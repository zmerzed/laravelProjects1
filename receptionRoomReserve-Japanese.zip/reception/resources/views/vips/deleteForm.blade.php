<div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">DELETE</h4>
        </div>
        <div class="modal-body">
            <div class="row">
                <form class="form-items2" role="form" method="POST" action="/vips/delete">
                    {{-- CSRF対策--}}
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                    <input type="hidden" name="id" value="{{ $vip->id }}">
                    <fieldset disabled>
                        <div class="col-sm-4 col-sm-offset-1 label-pos"><label for="inputName" class="sr-only_">NAME</label></div>
                        <div class="col-sm-6"><input type="text" id="inputName" class="form-control" name="name" value="{{ $vip->name }}" placeholder="" required autofocus></div>
                        <div class="col-sm-4 col-sm-offset-1 label-pos"><label for="inputEDate" class="sr-only_">ENTRY DATE</label></div>
                        <div class="col-sm-6"><input type="text" id="inputEDate" class="form-control" name="entry_date" value="{{ $vip->entry_date }}" placeholder="" required></div>
                        <div class="col-sm-4 col-sm-offset-1 label-pos"><label for="inputRenewal" class="sr-only_">RENEWAL</label></div>
                        <div class="col-sm-6"><input type="text" id="inputRenewal" class="form-control" name="renewal_date" value="{{ $vip->renewal_date }}" placeholder="" required></div>
                        <div class="col-sm-4 col-sm-offset-1 label-pos"><label for="inputExpiration" class="sr-only_">EXPIRATION</label></div>
                        <div class="col-sm-6"><input type="text" id="inputExpiration" class="form-control" name="expiration_date" value="{{ $vip->expiration_date }}" placeholder="" required></div>
                        <div class="col-sm-4 col-sm-offset-1 label-pos"><label for="inputVipId" class="sr-only_">VIP ID</label></div>
                        <div class="col-sm-6"><input type="text" id="inputVipId" class="form-control" name="vip_id" value="{{ $vip->vip_id }}" placeholder="" required></div>
                    </fieldset>
                    <div class="col-sm-12 col-xs-8 col-xs-offset-2">
                        <div class="row ptb15">
                            <div class="col-sm-6 col-sm-offset-3"><button class="btn btn-lg btn-primary btn-block item-btn-new" type="submit"><span>OK</span></button></div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
