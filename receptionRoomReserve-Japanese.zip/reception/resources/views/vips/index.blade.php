@extends('master')
  @section('content')

<script type="text/javascript">
$(function(){
  $("#new").on('click', function () {
    $('#myModal').load("/vips/createform",function(result){
      $('#myModal').modal('show');
    });
  });
  $("[id^=edit],[id^=delete]").on('click', function () {
    var url = $(this).attr("href");
    $('#myModal').load(url,function(result){
      $('#myModal').modal('show');
    });
    return false;
  });

});

$(window).load(function () {
    RECEPTION.alert.fadeOut(".alert-success");
});
</script>
@if (count($errors) > 0)
  <div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
    </ul>
  </div>
@endif
@if (session('message'))
  <div class="alert alert-success">
    {{ session('message') }}
  </div>
@endif
    <div class="row ptb15">
        <div class="col-sm-12 form-items2">
            <div class="row mtb15">
                <form method="GET" action="/vips/list">
                    <div class="col-sm-3 label-pos"><label for="vip_id" class="">VIP ID</label></div>
                    <div class="col-sm-4"><input type="text" id="vip_id" class="form-control" placeholder="" name="vip_id" value="{{ Input::get('vip_id') }}"></div>
                    <div class="col-md-2">
                        <button id="search" class="btn btn-primary" style="margin-right: 15px;">SEARCH</button>
                    </div>
                </form>
                <div class="col-sm-3">
                    <button id="new" class="btn btn-lg btn-primary btn-block" type="button" data-toggle="modal" data-target='#myModal'><span>NEW</span></button>
                    <!-- Modal -->
                    <div id="myModal" class="modal fade" role="dialog">
                    </div>
                </div>
            </div>

            <div class="row mtb15 ptb15">
                <div class="col-sm-12 table-responsive">
                    <table class="table table-striped table-bordered check-table">
                        <thead>
                            <tr>
				              	<th>Vip ID</th>
				              	<th>Name</th>
								<th>Renewal Date</th>
								<th></th>
							</tr>
			          </thead>
			          <tbody>
			          @foreach($vips as $vip)
			              <tr>
			                   <td>{{ $vip->vip_id }}</td>
			                   <td>{{ $vip->name }}</td>
			                   <td>{{ $vip->renewal_date }}</td>
			                   <td><a id="edit{{ $vip->id }}" href="/vips/editform/{{ $vip->id }}" >Edit</a> <span><a id="delete{{ $vip->id }}" href="/vips/deleteform/{{ $vip->id }}">X</a></span></td>
			              </tr>
			          @endforeach
			          </tbody>
			      </table>
				</div>
            </div>
        </div>
    </div>
  @endsection
