@extends('master')
  @section('content')
    <div class="row menu-items ptb15">
      <div class="col-sm-8">
        <div class="row">
            <ul class="text-center">
                <li class="col-sm-3"><a href="/slips/checkIn"><div class="menu-box"><span><i class="fa fa-check-square-o"></i>Check In</span></div></a></li>
                <li class="col-sm-3"><a href="/slips/checkOut"><div class="menu-box"><span><i class="fa fa-print"></i>Check Out</span></div></a></li>
                <li class="col-sm-3"><a href="/slips/list"><div class="menu-box"><span><i class="fa fa-files-o"></i>Slips</span></div></a></li>
                <li class="col-sm-3"><a href="/items"><div class="menu-box"><span><i class="fa fa-beer"></i>Items</span></div></a></li>
                @if (Auth::user()->role == 'admin')
                <li class="col-sm-3"><a href="/vips/list"><div class="menu-box"><span><i class="fa fa-black-tie fa-fw"></i>VIPs</span></div></a></li>
                <li class="col-sm-3"><a href="/items/adjustment"><div class="menu-box"><span><i class="fa fa-sliders"></i>Adjustment</span></div></a></li>
                <li class="col-sm-3"><a href="/items/list"><div class="menu-box"><span><i class="fa fa-tags"></i>Items</span></div></a></li>
                <li class="col-sm-3"><a href="/items/inventory"><div class="menu-box"><span><i class="fa fa-pencil"></i>Inventory</span></div></a></li>
                <li class="col-sm-3"><a href="/users/list"><div class="menu-box"><span><i class="fa fa-pencil"></i>Users</span></div></a></li>
                @endif
            </ul>
        </div>
      </div>
    </div>

  @endsection
