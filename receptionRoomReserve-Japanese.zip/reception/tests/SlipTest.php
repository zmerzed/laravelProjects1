<?php

use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class SlipTest extends TestCase
{

    protected $slip;

    public function setUp()
    {
        parent::setUp();
        $this->slip = new \App\Slip; 
    }

    public function additionProvider()
    {
        return array(
            'id 1' => array(1),
            'id 2' => array(2),
        );
    }

    /**
     * @dataProvider additionProvider
     */
    public function testSearch($id)
    {
        $condition = array("slips.id" => $id);
        $result = $this->slip->search($condition);
        if($this->assertArrayHasKey('0', $result)){
            $slip = $result[0];
            $this->assertObjectHasAttribute('id', $slip);
            $this->assertObjectHasAttribute('amenity_id', $slip);
            $this->assertObjectHasAttribute('customer', $slip);
            $this->assertObjectHasAttribute('check_in_date', $slip);
            $this->assertObjectHasAttribute('check_out_date', $slip);
            $this->assertObjectHasAttribute('amenity', $slip);
            $this->assertObjectHasAttribute('elapsed', $slip);
            $this->assertObjectHasAttribute('charge', $slip);
            $this->assertObjectHasAttribute('charge_code', $slip);
        }
    }

    /**
     * @dataProvider additionProvider
     */
    public function testSearchById($id)
    {
        $slip = $this->slip->searchById($id);
        $this->assertObjectHasAttribute('id', $slip);
        $this->assertObjectHasAttribute('amenity_id', $slip);
        $this->assertObjectHasAttribute('customer', $slip);
        $this->assertObjectHasAttribute('check_in_date', $slip);
        $this->assertObjectHasAttribute('check_out_date', $slip);
        $this->assertObjectHasAttribute('amenity', $slip);
        $this->assertObjectHasAttribute('elapsed', $slip);
        $this->assertObjectHasAttribute('charge', $slip);
        $this->assertObjectHasAttribute('charge_code', $slip);
    }

    public function testSearchWithPaginate()
    {
        $result = $this->slip->searchWithPaginate();
        $this->assertObjectHasAttribute('render', $result);
        if($this->assertArrayHasKey('0', $result)){
            $slip = $result[0];
            $this->assertObjectHasAttribute('id', $slip);
            $this->assertObjectHasAttribute('amenity_id', $slip);
            $this->assertObjectHasAttribute('customer', $slip);
            $this->assertObjectHasAttribute('check_in_date', $slip);
            $this->assertObjectHasAttribute('check_out_date', $slip);
            $this->assertObjectHasAttribute('amenity', $slip);
            $this->assertObjectHasAttribute('elapsed', $slip);
            $this->assertObjectHasAttribute('charge', $slip);
            $this->assertObjectHasAttribute('charge_code', $slip);
        }
    }
}
