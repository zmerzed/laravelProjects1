<?php

return [
    'user_logs' => 5,
    'observation_assignments' => 2000
];
