<?php

return [
    'employee' => [
        'admin' => 1,
        'hr'    => 2,
        'viewer' => 3
    ]
];