<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GoldenRule extends Model
{
    protected $table = 'golden_rules';
}
