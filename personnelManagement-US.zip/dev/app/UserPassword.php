<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPassword extends Model
{
    protected $table='password_hashes';
}
