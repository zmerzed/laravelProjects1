<?php

namespace App\Services;

use App\CorrectiveAction;
use App\Observation;
use App\Inspection;
use App\InductionComplete;
use App\Employee;
use Carbon\Carbon;
use DB;

class ChartService
{
    private static $colors = ['#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F'];
    private static $labels = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    private static $pieColors = ["#97BBCD", "#DCDCDC", "#F7464A", "#FDB45C"];
    //private static $currentYear = Carbon::now();

    public static function observations()
    {
        $colors = self::$colors;
        $labels = self::$labels;
        $currentYear = Carbon::now();
        $months = config('requirements.months');

        foreach($months as $month)
        {

            $start_date = "{$currentYear->year}-" . sprintf('%02s', $month) . '-01';
            $end_date = "{$currentYear->year}-" . sprintf('%02s', $month + 1) . '-01';
            $q = Observation::where('created_at', '>=', $start_date)->where('isSent', true);
            if($month != 12) {
                $q = $q->where('created_at', '<', $end_date);
            }

            $count = $q->get()->count();

            $data[] = $count;
        }

        $dataset =  [
            [
                "label"                 => "My First dataset",
                "backgroundColor"       => "red",
                "borderColor"           => "red",
                "borderWidth"           => 2,
                "hoverBackgroundColor"  => "red",
                "hoverBorderColor"      => "rgba(255,99,132,1)",
                "data"                  => [65, 59, 20, 81, 56, 55, 40]
            ]
        ];
        $barGraph = compact('labels', 'data', 'colors', 'dataset');

        /* observation categories count */
        $safetyCount        = Observation::where('category', 'safety')->where('isSent', true)->count();
        $environmentCount   = Observation::where('category', 'environment')->where('isSent', true)->count();
        $qualityCount       = Observation::where('category', 'quality')->where('isSent', true)->count();
        $publicCount        = Observation::where('category', 'public')->where('isSent', true)->count();

        $circle_colors = self::$pieColors;
        $circle1_labels = ['SAFETY', 'ENVIRONMENT', 'QUALITY', 'PUBLIC'];

        $circle1_data = [$safetyCount, $environmentCount, $qualityCount, $publicCount];

        $circle1_dataset = array('borderWidth' => 0);
        $circle1 = [
            'data' => $circle1_data,
            'colors' => $circle_colors,
            'labels' => $circle1_labels,
            'dataset' => $circle1_dataset
        ];

        $positiveCount = Observation::where('type', '>', 0)->where('isSent', true)->count();
        $negativeCount = Observation::where('type', '<=', 0)->where('isSent', true)->count();

        $circle2_labels = ['POSITIVE', 'NEGATIVE'];

        $circle2_data = [$positiveCount, $negativeCount];
        $circle2_dataset = array('borderWidth' => 0);

        $circle2 = [
            'data' => $circle2_data,
            'colors' => $circle_colors,
            'labels' => $circle2_labels,
            'dataset' => $circle2_dataset
        ];

        return [
            'bar_graph' => $barGraph,
            'circle1'   => $circle1,
            'circle2'   => $circle2
        ];
    }

    public static function inspections()
    {
        $colors = self::$colors;
        $labels = self::$labels;
        $currentYear = Carbon::now();
        $months = config('requirements.months');

        foreach($months as $month)
        {
            $start_date = "{$currentYear->year}-" . sprintf('%02s', $month) . '-01';
            $end_date = "{$currentYear->year}-" . sprintf('%02s', $month + 1) . '-01';
            $q = Inspection::where('created_at', '>=', $start_date)
                ->where('isClone', true)
                ->where('isSetup', true);

            if($month != 12)
            {
                $q = $q->where('created_at', '<', $end_date);
            }

            $count = $q->get()->count();
            $data[] = $count;
        }

        $barGraph = compact('labels', 'data', 'colors');

        /* inspection item count for positive and negative (compliance or non comp) */

        $positiveCount = 0;
        $negativeCount = 0;
        $inspections = Inspection::where('isClone', true)
            ->where('isSetup', true)
            ->where('inspected_by', '!=', NULL)
            ->get();

        foreach($inspections as $i)
        {
            if($i->isAction()) {
                $positiveCount++;
            } else {
                $negativeCount++;
            }
        }

        $circle1_colors = self::$pieColors;
        $circle1_labels = ['Needs Action', 'No action needed'];

        $circle1_data = [$positiveCount, $negativeCount];
        $circle1_dataset = array('borderWidth' => 0);
        $circle1 = [
            'data' => $circle1_data,
            'colors' => $circle1_colors,
            'labels' => $circle1_labels,
            'dataset' => $circle1_dataset
        ];

        return [
            'bar_graph' => $barGraph,
            'circle1'   => $circle1
        ];
    }

    public static function skillGaps()
    {

        $colors = self::$colors;
        $labels = self::$labels;
        $currentYear = Carbon::now();
        $data = [];

        $months = config('requirements.months');
        foreach($months as $month)
        {
            $start_date = "{$currentYear->year}-" . sprintf('%02s', $month) . '-01';
            $end_date = "{$currentYear->year}-" . sprintf('%02s', $month + 1) . '-01';
            $q = Employee::where('skilled_date', '>=', $start_date)->where('skilled', true);

            if($month != 12)
            {
                $q = $q->where('skilled_date', '<', $end_date);
            }

            $count = $q->get()->count();
            $data2[] = $count;
            $data[] = $count;
        }

        $barGraph = compact('labels', 'data', 'colors');

        $positiveCount = 20;
        $negativeCount = 50;

        $circle1_colors = self::$pieColors;
        $circle1_labels = ['SKILLS GAP', 'SKILLED'];

        $circle1_data = [$positiveCount, $negativeCount];
        $circle1_options = array(
            'legend' => ['display' => true, 'position' => 'bottom']
        );

        $circle1_dataset = array('borderWidth' => 0);
        $circle1 = [
            'data' => $circle1_data,
            'colors' => $circle1_colors,
            'labels' => $circle1_labels
        ];

        return [
            'bar_graph' => $barGraph,
            'circle1'   => $circle1,
            'data2'     => $data2
        ];
    }

    public static function onlineTraining()
    {
        $colors = self::$colors;
        $labels = self::$labels;
        $currentYear = Carbon::now();
        $months = config('requirements.months');

        foreach($months as $month)
        {
            $start_date = "{$currentYear->year}-" . sprintf('%02s', $month) . '-01';
            $end_date = "{$currentYear->year}-" . sprintf('%02s', $month + 1) . '-01';
            $q = \App\OnlineTraining::where('created_at', '>=', $start_date);
            if($month != 12) {
                $q = $q->where('created_at', '<', $end_date);
            }

            $count = $q->get()->count();

            $data[] = $count;
        }

        $options = [
            "scales" =>
                [
                    "xAxes" => [
                        array(
                            "gridLines" => array("display" => false)
                        )
                    ],
                    "yAxes" => [
                        array(
                            "scaleShowLabels" => false,
                            "ticks" => array("beginAtZero" => true),
                            "display" => true,
                            "gridLines" => array(
                                "display" => true,
                                "offsetGridLines" => false
                            )
                        )
                    ]
                ]
        ];

        $barGraph = compact('labels', 'data', 'options', 'colors');

        return [
            'bar_graph' => $barGraph
        ];
    }

    public static function correctActions()
    {
        $colors = self::$colors;
        $labels = self::$labels;
        $currentYear = Carbon::now();
        $months = config('requirements.months');

        foreach($months as $month)
        {
            $start_date = "{$currentYear->year}-" . sprintf('%02s', $month) . '-01';
            $end_date = "{$currentYear->year}-" . sprintf('%02s', $month + 1) . '-01';
            $q = CorrectiveAction::where('created_at', '>=', $start_date);
            if($month != 12) {
                $q = $q->where('created_at', '<', $end_date);
            }

            $count = $q->get()->count();

            $data[] = $count;
        }

        $barGraph = compact('labels', 'data', 'colors');

        /* observation categories count */
        $correctives = CorrectiveAction::all();

        $count_open       = 0;
        $count_closedOut  = 0;
        $count_overdue    = 0;
        $count_inprogress = 0;

        //dd($correctives->toArray());
        foreach($correctives as $c)
        {
            switch($c->status['text'])
            {
                case 'OPEN':
                {
                    $count_open++;
                    }break;
                case 'CLOSED OUT':
                {
                    $count_closedOut++;
                    }break;
                case 'OVERDUE':
                {
                    $count_overdue++;
                    }break;
                case 'IN PROGRESS':
                {
                    $count_inprogress++;
                    }break;
            }
        }

        $circle1_colors = ["#e97472", "#f29b50", "#63c169", "#157cc4"];
        $circle1_labels = ['OVERDUE', 'IN PROGRESS', 'OPEN', 'CLOSED OUT'];

        $circle1_data = [$count_overdue, $count_inprogress, $count_open, $count_closedOut];

        $circle1_dataset = array('borderWidth' => 0);
        $circle1 = [
            'data' => $circle1_data,
            'colors' => $circle1_colors,
            'labels' => $circle1_labels,
            'dataset' => $circle1_dataset
        ];

        return [
            'bar_graph' => $barGraph,
            'circle1'   => $circle1
        ];
    }

    public static function inductions()
    {
        $colors = self::$colors;
        $labels = self::$labels;
        $currentYear = Carbon::now();
        $months = config('requirements.months');

        foreach($months as $month)
        {
            $start_date = "{$currentYear->year}-" . sprintf('%02s', $month) . '-01';
            $end_date   = "{$currentYear->year}-" . sprintf('%02s', $month + 1) . '-01';
            $q          = InductionComplete::where('created_at', '>=', $start_date);

            if($month != 12) {
                $q = $q->where('created_at', '<', $end_date);
            }

            $count = $q->get()->count();
            $data[] = $count;
        }

        $barGraph = compact('labels', 'data', 'colors');

        $now = Carbon::now();
        $total_completed = InductionComplete::all()->count();
        $this_month = InductionComplete::where('created_at', '>=', $now->startOfMonth())->count();
        $this_week = InductionComplete::where('created_at', '>=', $now->startOfWeek())->count();
        $today = InductionComplete::whereDate('created_at', DB::raw('CURDATE()'))->count();
        $max = InductionComplete::all()->count();
        $counts = [
            'total_completed'  => $total_completed,
            'this_month'       => $this_month,
            'this_week'        => $this_week,
            'today'            => $today,
            'max'              => $max
        ];

        $circle1_labels = ['TOTAL COMPLETED', 'THIS MONTH', 'THIS WEEK', 'TODAY'];
        $circle1_data = [$total_completed, $this_month, $this_week, $today];
        $circle1_dataset = array('borderWidth' => 0);

        $circle1 = [
            'data' => $circle1_data,
            'labels' => $circle1_labels,
            'dataset' => $circle1_dataset
        ];

        return [
            'bar_graph' => $barGraph,
            'counts' => $counts,
            'circle'  => $circle1
        ];
    }
}
