<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Helpers\AppHelper;
use App\Http\Helpers\ConstantHelper;
use App\Services\ChartService;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Observation;
use App\Inspection;
use App\CorrectiveAction;
use App\OnlineTraining;
use DB;

use Carbon\Carbon;

class RegisterController extends Controller {

    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    protected function observations()
    {
        $observations = Observation::where('company_id', AppHelper::decrypt($this->request->route('id')))
                        ->where('isSent', true)
                        ->orderBy('created_at', 'desc')
                        ->get();

        foreach($observations as $observation)
        {
            $observation->sub_categories = $observation->subCategoriesToString();

            if(is_null($observation->status)) {
                $observation->status = 4;
            }

            $observation->status = config('requirements.observation_status')[$observation->status];
        }


        return Response()->json([
            'result' => true,
            'observations' => ['data' => $observations],
            'charts' => ['data' => ChartService::observations()]
        ]);
    }

    protected function inspections()
    {
        $inspections = Inspection::where('inspected_by', '!=', NULL)
            ->where('isSetup', true)
            ->where('isClone', true)
            ->orderBy('created_at', 'desc')
            ->get();

        $inspections->each(function($i)
        {

            if($i->inspected_by) {
                $i->inspector_name = $i->inspectedBy->first_name . ' ' . $i->inspectedBy->last_name;
            }

            $i->compliant_count = $i->getComplianceNonInfo();
            $i->category = $i->category;

            if(is_null($i->status)) {
                $i->status = ConstantHelper::$INSPECTION_IN_PROGRESS;
            }
            
        });

        return Response()->json([
            'result'        => true,
            'inspections'   => ['data' => $inspections],
            'charts'        => ['data' => ChartService::inspections()]
        ]);
    }

    protected function correctiveActions()
    {

        $actions = CorrectiveAction::with('inspectionItem')
            ->where('company_id', AppHelper::decrypt($this->request->id))
            ->orderBy('updated_at', 'desc')
            ->paginate(25);

        return Response()->json([
            'result'                => true,
            'test'                  => $actions,
            'corrective_actions'    => ['data' => $actions],
            'charts'                => ['data' => ChartService::correctActions()]
        ]);
    }

    protected function correctActionExport()
    {
        $actions = CorrectiveAction::where('company_id', AppHelper::decrypt($this->request->id));

         if($this->request->from && $this->request->to)
         {
             $from = Carbon::parse(str_replace('-', '/', trim($this->request->from)));
             $to   = Carbon::parse(str_replace('-', '/', trim($this->request->to)));

             $actions = $actions->whereDate('created_at', '>=', $from)
                        ->whereDate('created_at', '<=', $to);
         }

        $actions = $actions->get();

        foreach($actions as $a) {
            $a->s_date   = $a['date']['text'];
            $a->s_name   = $a['name']['text'];
            $a->s_result = $a['result']['text'];
            $a->s_type   = $a['type']['text'];
            $a->s_seen   = $a['seen']['text'];
            $a->s_status = $a['status']['text'];
            $a->s_due    = $a['due']['text'];
        }

        $filename = 'corrective_actions_'. str_replace("-", "", $this->request->from . "_" . $this->request->to) . ".csv";
        $columns = array(
            'Date'   => 's_date',
            'Name'   => 's_name',
            'Result' => 's_result',
            'Type'   => 's_type',
            'Seen'   => 's_seen',
            'Status' => 's_status',
            'Due'    => 's_due'
        );

        AppHelper::export($filename, $columns, $actions);
    }

    protected function csvOnlineTraining()
    {

        $trainings = OnlineTraining::whereCompanyId(
            AppHelper::decrypt($this->request->route('id')))
            ->where('created_at', '>=',  Carbon::createFromFormat("m-d-Y", $this->request->from))
            ->where('created_at', '<=',  Carbon::createFromFormat("m-d-Y", $this->request->to))
            ->get();

        $from = Carbon::createFromFormat("m-d-Y", $this->request->from)->format("dmY");
        $to = Carbon::createFromFormat("m-d-Y", $this->request->to)->format("dmY");

        $filename = "OnlineTraining_{$from}_{$to}.csv";

        $columns = array(
            'Date' 	    => 'created_at',
            'Employee'  => 'full_name',
            'Type' 	    => 'type',
            'Title'     => 'title'
        );

        AppHelper::export($filename, $columns, $trainings);
    }

    protected function completedTrainings()
    {
        $companyId = AppHelper::decrypt($this->request->route('id'));

        $this->request->keywords
            ? $keywords = $this->request->get('keywords') : $keywords = '';

        $trainings = OnlineTraining::where('company_id', $companyId);
        $trainings = $trainings->search( $keywords, ['full_name' => 10, 'title' => 10])
            ->orderBy('id', 'desc')
            ->paginate(25);

        return Response()->json([
            'result'              => true,
            'completed_trainings' => ['data' => $trainings],
            'charts'              => ['data' => ChartService::onlineTraining()]
        ]);
    }
    
    protected function inductions()
    {
        return Response()->json([
            'result'  => true,
            'charts'  => ['data' => ChartService::inductions()]
        ]);
    }

}
