<?php

namespace App\Observers;

use Auth;
use App\Observation;
use App\CorrectiveAction;

class ObservationObserver
{
    /**
     * Listen to the User created event.
     *
     * @param  User  $user
     * @return void
     */
    public function created(Observation $observation)
    {
    }

    /**
     * Listen to the User deleting event.
     *
     * @param  User  $user
     * @return void
     */
    public function deleting(Observation $observation)
    {
        //
    }
}