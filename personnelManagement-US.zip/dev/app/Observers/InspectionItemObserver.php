<?php

namespace App\Observers;

use App\InspectionItem;
use App\CorrectiveAction;
use Auth;


class InspectionItemObserver
{
    /**
     * Listen to the User created event.
     *
     * @param  User  $user
     * @return void
     */
    public function created(InspectionItem $i)
    {
        dd('llf');

    }

    public function updated(InspectionItem $i){
        dd('xxxxxxxxxxxxxxxxxx');
    }

    /**
     * Listen to the User deleting event.
     *
     * @param  User  $user
     * @return void
     */
    public function deleting(InspectionItem $i)
    {
        //
    }
}