<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Erp extends Model
{
    protected $table = 'erp_details';
}
