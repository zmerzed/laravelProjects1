<?php

namespace App;

use App\Company;
use App\User;
use App\Employee;
use App\Feature;
use App\Module;

class HelixStats
{
    public function getTotalCompanies()
    {
        return Company::all()->count();
    }

    public function getTotalUsers()
    {
          return User::all()->count();
    }

    public function getTotalEmployees()
    {
        return Employee::all()->count();
    }

    public function getTotalUsersByCompany($id)
    {
          return Employee::all()->where('company_id', $id)->count();
    }

    public function getTotalFeatures()
    {
        return Feature::all()->count();
    }

    public function getAverageModules()
    {
        //$avg = Module::distinct()->get(['feature_id'])->count();
        $numModules = Module::get(['feature_id'])->count();
        $numCompanies = Module::distinct()->get(['company_id'])->count();
        $avg = (int) ($numModules / $numCompanies);
        return $avg . '/9';
    }

    public function getDailyHits()  {
        return "-";
    }

    public function getWeeklyHits()
    {
        return "-";
    }

    public static function getStats()
    {
        $stat = new self();
        return [
            [ 'image_url' => '/img/client.png', 'name' => 'Clients', 'count' => $stat->getTotalCompanies() ],
            [ 'image_url' => '/img/users.png', 'name' => 'Users', 'count' => $stat->getTotalEmployees() ],
            //[ 'image_url' => '/img/module.png', 'name' => 'Modules', 'count' => $stat->getTotalFeatures() ],
            [ 'image_url' => '/img/avg-module.png', 'name' => 'Average Modules', 'count' => $stat->getAverageModules() ],
            [ 'image_url' => '/img/daily-hits.png', 'name' => 'Daily Hits', 'count' => $stat->getDailyHits() ],
            [ 'image_url' => '/img/weekly-hits.png', 'name' => 'Weekly Hits', 'count' => $stat->getWeeklyHits() ]
        ];
    }

    public static function getStatsCompanyEdit($id)
    {
        $stat = new self();
        return [
            [ 'image_url' => '/img/users.png', 'name' => 'Users', 'count' => $stat->getTotalUsersByCompany($id) ],
            [ 'image_url' => '/img/daily-hits.png', 'name' => 'Daily Hits', 'count' => $stat->getDailyHits() ],
            [ 'image_url' => '/img/weekly-hits.png', 'name' => 'Weekly Hits', 'count' => $stat->getWeeklyHits() ]
        ];
    }
}
