<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SkillItem extends Model
{
    protected $table = 'skill_items';
    
}
