<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeDoc extends Model
{
    protected $table = 'employee_docs';
    
}
