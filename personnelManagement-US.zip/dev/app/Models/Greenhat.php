<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Greenhat extends Model
{
    protected $table = 'greenhat_programs';

    protected $fillable = [
    	'user_id', 
    	'company_id', 
    	'supervisor_id', 
    	'status', 
    	'const_mgmt_id', 
    	'plant_dept_id', 
    	'env_evaluator_id', 
    	'ohs_evaluator_id', 
    	'hr_followup_id', 
    	'created_by',
    	'comment',
    ];


	public function user()
	{
		return $this->belongsTo('App\User', 'user_id', 'id');
	}

	public function feedbacks()
	{
		return $this->hasMany('App\Models\GreenhatFeedback', 'greenhat_program_id', 'id');
	}

	public function supervisor()
	{
		return $this->belongsTo('App\User', 'supervisor_id', 'id');
	}

	public function constManager()
	{
		return $this->belongsTo('App\User', 'const_mgmt_id', 'id');
	}

	public function plantDept()
	{
		return $this->belongsTo('App\User', 'plant_dept_id', 'id');
	}

	public function environment()
	{
		return $this->belongsTo('App\User', 'env_evaluator_id', 'id');
	}

	public function hr()
	{
		return $this->belongsTo('App\User', 'hr_followup_id', 'id');
	}

	public function ohs()
	{
		return $this->belongsTo('App\User', 'ohs_evaluator_id', 'id');
	}

}
