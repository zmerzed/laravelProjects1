<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChemicalCategory extends Model
{
    protected $table = 'chemical_categories';
}
