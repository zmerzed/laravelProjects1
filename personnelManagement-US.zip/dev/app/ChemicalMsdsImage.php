<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChemicalMsdsImage extends Model
{
    protected $table = 'chemical_msds_images';
}
