<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use App\Http\Helpers\AppHelper;
use App\Http\Helpers\ConstantHelper;
use App\Module;
use App\Feature;
use Sofa\Eloquence\Eloquence;
use DB;

class Company extends Model
{
    use Eloquence;

    protected $table = "companies";

    protected $fillable = [
        'name',
        'link',
        'contact_name',
        'website',
        'email',
        'accounts_contact',
        'accounts_email',
        'mobile',
        'head_office_state',
        'abn',
        'status',
        'state_id',
        'created_by',
        'deleted_at',
        'created_at',
        'updated_at'
    ];

    protected $appends = [
        'modules_str',
        'modules_availability'
    ];

    public function createdBy()
    {
        return $this->belongsTo('App\HelixUser', 'created_by', 'id');
    }

    public function state()
    {
        return $this->belongsTo('App\State', 'state_id', 'id');
    }

    public function modules()
    {
        $modules = DB::table('modules')
                    ->where('company_id', $this->id)
                    ->where('key', '!=', 'incidents')
                    ->get();

        if($modules) {
            return $modules;
        }

        return [];
    }

    public function modulesIds()
    {
        $modules = $this->modules()->get();
        $arrModules = [];
        foreach($modules as $m) {
            $arrModules[] = $m->id;
        }

        return $arrModules;
    }

    public function insertModules($modules)
    {
        $date_time = new \DateTime();
        /* */
        DB::table('modules')->where('company_id', $this->id)->delete();
        foreach($modules as $m)
        {
            $feature = Feature::where('key', $m)->first();

            if($feature)
            {

                DB::table('modules')->insert([
                    [
                        'company_id' => $this->id,
                        'key' => $m,
                        'status' => 1,
                        'feature_id' => $feature->id,
                        'created_at'=>$date_time,
                        'updated_at'=>$date_time
                    ]
                ]);
            }
        }
    }

    public function logs()
    {
        return $this->hasMany('App\Log');
    }

    public function getCompanyLogoPath()
    {
        return ConstantHelper::$BASE_PUBLIC_PATH."companies/logo/{$this->id}/";
    }

    public function logo()
    {
        /* if company is only a test data */
        if($this->isSample)
        {
            return '../../img/client/company-logo.png';
        }

        $logo = db::table('company_logos')->where('company_id', $this->id)->first();

        if($logo) {
            return config('fileapi.path_company_main_logo') . $this->id . '/' . $logo->filename;
        }

        return '/img/helix-logo.jpg';
    }

    public function cryptedId()
    {
        return AppHelper::encrypt($this->id);
    }

    public function getModulesStrAttribute()
    {

        $modules = $this->modules();
        $keys = [];

        foreach($modules as $m)
        {
            $module = Feature::find($m->feature_id);

            if($module) {
                $keys[] = $module->key;
            }
        }

        return $keys;
    }
    
    public function getModulesAvailabilityAttribute()
    {
        $modulesStr = $this->modules_str;
        $keys = [];

        foreach($modulesStr as $module)
        {
            $keys[] = $module;
        }

        return [
            'observations'   => ['portal' => in_array('observations', $keys), 'client' => in_array('observations', $keys)],
            'safety_vids'   => ['portal' => in_array('safety_vids', $keys), 'client' => in_array('safety_vids', $keys)],
            'inspection'    => ['portal' => in_array('inspection', $keys), 'client' => in_array('inspection', $keys)],
            'inductions'    => ['portal' => in_array('inductions', $keys), 'client' => in_array('inductions', $keys)],
            'chemical_mgt'  => ['portal' => in_array('chemical_mgt', $keys), 'client' => in_array('chemical_mgt', $keys)]
        ];
    }
}
