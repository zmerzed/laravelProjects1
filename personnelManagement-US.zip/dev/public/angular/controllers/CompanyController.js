(function () {
    'use strict';

    angular
        .module('app')
        .controller('CompanyController', CompanyController)
        .controller('CompanyAddController', CompanyAddController)
        .controller('CompanyEditController', CompanyEditController);

    function CompanyController(
        $http,
        baseUrl,
        CompanyService
    ) {
        var company = this;
        company.companies = [];
        company.search = search;
        company.keywords = '';
        company.params = '';

        init();

        function init()
        {
            $http.get(
                baseUrl.helix_admin + '/company/lists'
            ).then(function(res){
                company.companies = res.data.companies.data;
                company.stats = res.data.stats.data;
            });
        }

        function search()
        {
            company.params = '?keywords=' + company.keywords;
            console.log(company.params);
            CompanyService.search(
                company.params
            ).then(function(res) {
                company.companies = res.data.companies.data;
            });
        }
    }

    function CompanyAddController(
        $http,
        GlobalService,
        baseUrl,
        $state,
        $scope
    ) {
        var company = this;
        company.save = save;
        company.new = {};
        company.modules = GlobalService.global.modules;

        init();

        function init()
        {

        }

        function save()
        {
            console.log(company.new);
            var filteredModules = [];
            var formData = new FormData();
            var companyLogo = document.getElementById('company_logo').files[0];

            for(var i in company.modules)
            {
                var module = company.modules[i];
                if(module.isChecked) {
                    filteredModules.push(module.key);
                }
            }
            company.new.modules = filteredModules;

            if(typeof companyLogo != 'undefined') {
                formData.append('company_logo', companyLogo);
            }

            for(var i in company.new) {
                formData.append(i, company.new[i]);
            }

            $http.post(baseUrl.helix_admin + '/company/add', formData, {headers: {'Content-Type': undefined, 'Process-Data':false}}).then(function(res) {
                $state.go('main.companies.list');
            }).catch(function(res) {
                $scope.ajaxMessages(res);
            });
        }
    }

    function CompanyEditController(
        $http,
        $stateParams,
        $state,
        baseUrl,
        GlobalService,
        $scope,
        CompanyService
    ) {
        var company = this;
        company.update = update;
        company.log = {
            nextPage : nextPage,
            prevPage : prevPage,
            goPage   : goPage,
            currentPage : 1,
            pagination  : {},
            list: []
        };

        company.view = {};
        company.modules = angular.copy(GlobalService.global.modules);

        init();

        function init()
        {
            $http.get(baseUrl.helix_admin + '/company/' + $stateParams.id + '/view')
                .then(function(res)
                {
                    console.log(res);
                    company.view = res.data.company.data;
                    company.stats = res.data.stats;

                    var modules = company.view.modules;

                    for(var i in modules)
                    {
                        var module = modules[i];
                        for(var x in company.modules) {
                            if(module.key == company.modules[x].key) {
                                company.modules[x].isChecked = true;
                            }
                        }
                    }
                });

            CompanyService.getLogs(
                $stateParams.id,
                ''
            ).then(function(res) {
                company.log.pagination = res.data.logs.data;
                company.log.list = company.log.pagination.data;
            })
        }

        function update()
        {
            var filteredModules = [];
            var formData = new FormData();
            var companyLogo = document.getElementById('company_logo').files[0];

            for(var i in company.modules)
            {
                var module = company.modules[i];
                if(module.isChecked) {
                    filteredModules.push(module.key);
                }
            }
            company.view.modules = filteredModules;

            if(typeof companyLogo != 'undefined') {
                formData.append('company_logo', companyLogo);
            }

            for(var i in company.view) {
                formData.append(i, company.view[i]);
            }

            $http.post(baseUrl.helix_admin + '/company/' + company.view.id +'/update', formData, {headers: {'Content-Type': undefined, 'Process-Data':false}}).then(function(res) {
                $state.go('main.companies.list');
            }).catch(function(res) {
                $scope.ajaxMessages(res);
            });
        }

        function nextPage()
        {
            if(company.log.currentPage >=
                company.log.pagination.last_page
            ) {
                return false;
            }

            company.log.currentPage++;
            action('?page='+company.log.currentPage);
        }

        function prevPage()
        {
            if(company.log.currentPage <= 1) {
                return false;
            }

            company.log.currentPage--;
            action('?page='+company.log.currentPage);
        }

        function goPage(page)
        {
            company.log.currentPage = page;
            action('?page='+company.log.currentPage);
        }

        function action(params)
        {
            if(typeof params === 'undefined')
            {
                params = '';
            }

            CompanyService.getLogs(
                $stateParams.id,
                params
            ).then(function(res) {
                company.log.pagination = res.data.logs.data;
                company.log.list = company.log.pagination.data;
            })
        }
    }
})();
