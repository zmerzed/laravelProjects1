(function () {
    'use strict';

    angular
        .module('app')
        .controller('UsersController', UsersController)
        .controller('UserViewController', UserViewController)
        .controller('UserAddController', UserAddController);

    function UsersController(
        UserService,
        $state
    ) {
        var user = this;
        user.removeUser = removeUser;

        init();

        function init()
        {
            console.log("USERS CONTROLLER");
            UserService.search('').then(function(res) {
                console.log(res);
                user.list = res.data.helix_users.data;
            });
        }

        function removeUser(id)
        {

            var alert = confirm("Are you sure you want to delete this item?");

            if(alert)
            {
                UserService.remove(id).then(function(res) {
                    $state.reload();
                });
            }
        }
    }

    function UserAddController(
       UserService
    ) {
        let user = this;
        user.save = save;

        init();

        function init()
        {
            console.log("USER ADD CONTROLLER");
        }

        function save()
        {
            var formData = new FormData();


            var file = document.getElementById('idUserAvatar').files[0];

            if(typeof file != 'undefined') {
                formData.append('avatar', file);
            }


            for(var i in user.new) {
                formData.append(i, user.new[i]);
            }

            UserService.add(
                formData
            ).then(function(res){
                console.log(res);
                $state.go('main.users.list');
            })
        }
    }

    function UserViewController(
        UserService,
        $state,
        $stateParams
    ) {
        let user = this;
        user.remove = remove;
        user.resetPassword = resetPassword;
        user.removeMessage = removeMessage;
        user.messages = {errors: [], success: []};

        init();

        function init()
        {
            
            if(!$stateParams.id)
            {
                $state.go('main.users.list');
            }

            UserService.view(
                $stateParams.id
            ).then(function(res){
                user.view = res.data.helix_user.data;
            });
            
        }

        function resetPassword()
        {
            var alert = confirm("Are you sure you want to reset this user password?");

            if(alert)
            {
                UserService.resetPassword(
                    user.view.id
                ).then(function(res) {
                    user.messages.success.push('Success resetting password');
                    console.log('change password');
                });
            }
        }

        function removeMessage(message, type)
        {
            var idx = user.messages[type].indexOf(message);
            user.messages[type].splice(idx)
        }

        function remove()
        {
            var alert = confirm("Are you sure you want to delete this item?");

            if(alert)
            {
                UserService.remove(
                    user.view.id
                ).then(function(res) {
                    $state.go('main.users.list');
                });
            }
        }
    }
})();
