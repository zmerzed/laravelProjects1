app.controller('AppController', function(
    $scope,
    Auth,
    $state,
    $http,
    baseUrl,
    $localStorage
) {
    $scope.app = {};
    $scope.bgLogin = true;
    $scope.loader;

    $scope.showToastr = showToastr;
    $scope.ajaxMessages = ajaxMessages;

    $scope.app.checkCurrentPagination = function(page, currentPage)
    {
        if(page == currentPage) {
            return true
        }
        return false;
    };
    
    /**
     * @params ------ response from ajax
     * obj - config, data, headers, status, statusText
     * output - it will display a toaster message
     */
    function ajaxMessages(obj)
    {
        var status = '';

        toastr.remove();


        switch(obj.status)
        {
            case 200: {
                status = 'success';
                } break;
            case 400: {
                status = 'error';
                } break;
            default: {
                status = 'error';
                } break;
        }

        if(obj.data.hasOwnProperty('message'))
        {
            var messages = obj.data.message

            for(var i in messages)
            {
                for(var x in messages[i])
                {
                    toastr[status](messages[i][x]);
                }
            }
        }
    }

    function showToastr(status, message)
    {
        var i;
        toastr.remove();

        if(typeof message == 'object')
        {
            for (i in message)
            {
                if (message.hasOwnProperty(i))
                {
                    if(message[i].hasOwnProperty('type'))
                    {
                        status = message[i].type;
                        toastr[status](message[i].message);
                    } else {
                        toastr[status](message[i]);
                    }
                }
            }
        } else {
            toastr[status](message);
        }
    }

});
app.controller('DropdownCtrl', function($scope, $log) {
    $scope.status = {
        isopen: false
    };

    $scope.toggled = function(open) {
    };

    $scope.toggleDropdown = function($event) {
        $event.preventDefault();
        $event.stopPropagation();
        $scope.status.isopen = !$scope.status.isopen;
    };
});
