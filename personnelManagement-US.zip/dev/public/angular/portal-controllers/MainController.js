(function () {
    'use strict';

    angular
        .module('app')
        .controller('MainController', Controller)
        .controller('OverallStatistics', OverallStatistics)
        .controller('SubconStatistics', SubconStatistics)
        .controller('HRStatistics', HRStatistics)
        .controller('OHSStatistics', OHSStatistics);

    function Controller(
        $localStorage,
        $scope,
        dashboardChartOption,
        barChartOption,
        pieChartColor,
        SkillGapService,
        RegisterService
    ) {
        var main = this;
        main.charts = {};

        initController();

        function initController()
        {
            // Test data

            $scope.pieChartColorClass = pieChartColor;
            $scope.pieChartColor = ["#97BBCD", "#DCDCDC", "#F7464A", "#FDB45C"];

            $scope.labels3 = ["Overdue", "In Progress", 'Open', 'Closed Out'];
            $scope.data3 = [5, 20, 30, 5];

            $scope.labels4 = ['Skilled Gap', 'Skilled'];
            $scope.data4 = [20, 30];

            $scope.labels5 = ["Total Completed", "This Month", 'This Week', 'Today'];
            $scope.data5 = [1, 1, 1, 0];

            $scope.labels6 = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
            $scope.data6 = [2, 4, 9, 11, 5, 6, 7, 3, 15, 10, 2, 20];
            $scope.color6 = ['#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F'];
            $scope.options6 = {
                scales: {
                    xAxes: [{
                        gridLines: {
                            display: true,
                            drawBorder: true,
                            offsetGridLines: true
                        }
                    }],
                    yAxes: [{
                        ticks: {
                            beginAtZero: true,
                            stepSize: 5,
                            callback: function(value, index, values) {
                                return '';
                            }
                        },
                        display: true,
                        gridLines:{
                            display: true,
                            drawOnChartArea: false,
                            drawBorder: true,
                            drawTicks:false,
                            offsetGridLines: true
                        }
                    }]
                }
            };

            main.charts.baroption = dashboardChartOption;
            if($localStorage.currentUser) {
                main.currentUser = $localStorage.currentUser;
                $scope.bgLogin = false;
            }

            RegisterService.getObservations().then(function(res)
            {
                main.charts.observations = res.data.charts.data;
            });

            RegisterService.getInspections().then(function(res)
            {
                main.charts.inspections = res.data.charts.data;
            });

            RegisterService.getCorrectiveActions().then(function(res)
            {
                main.charts.corrective_actions = res.data.charts.data;
                main.charts.baroption2 = dashboardChartOption;
            });

            RegisterService.getSkillGaps().then(function(res)
            {
                var charts = res.data.analytics.data.charts;
                var graph = res.data.analytics.data.graph;

                main.charts.skill_gaps = charts;
                main.charts.skill_gaps.bar_graph.data = graph.monthly_skilled;
                main.charts.skill_gaps.circle1.data[0] = graph.skills_gap;
                main.charts.skill_gaps.circle1.data[1] = graph.skilled;
            });

            RegisterService.getInductions().then(function(res)
            {
                main.charts.inductions = res.data.charts.data;
            });

            RegisterService.getOnlineTraining().then(function(res){
                main.charts.online = res.data.charts.data;
            });

        }
    }

    function OverallStatistics($scope) {
        $scope.colors = ['#45b7cd', '#ff6384'];
        $scope.labels = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
        $scope.series = ['Series A', 'Series B'];
        $scope.data = [
            [30, 10, 20, 25, 35, 20, 30, 40, 35, 50, 15, 40],
            [5, 15, 28, 10, 15, 25, 18, 15, 39, 35, 11, 22]
        ];

        $scope.onClick = function (points, evt) {
            console.log(points, evt);
        };

        $scope.options = {
            elements: {
                line: {
                    tension: 0
                }
            },
            scales: {
                xAxes: [{
                    gridLines: {
                        display: false
                    }
                }],
                yAxes: [{
                    scaleShowLabels : false,
                    ticks: {
                        beginAtZero: true
                    },
                    display: true,
                    gridLines: {
                        display: true,
                        offsetGridLines: false
                    },
                }]
            }
        };
    }

    function SubconStatistics($scope){
        // $scope.colors = ['#f1a296'];
        $scope.colors = [{
            backgroundColor      :"#F1A296",
            hoverBackgroundColor :"#F1A296",
            borderColor          :"#F1A296",
            hoverBorderColor     :"#F1A296"
        }];
        $scope.labels = ["2011", "2012", "2013", "2014", "2015", "2016"];
        $scope.data = [
            [23, 26, 32, 30, 31, 35]
        ];

        $scope.onClick = function (points, evt) {
            console.log(points, evt);
        };

        $scope.options = {
            scales: {
                xAxes: [{
                    gridLines: {
                        display: false
                    }
                }],
                yAxes: [{
                    scaleShowLabels : false,
                    ticks: {
                        beginAtZero: true
                    },
                    display: true,
                    gridLines: {
                        display: true
                    },
                }]
            }
        };
    }

    function HRStatistics($scope){
        // $scope.colors = ['#7EE4BE'];
        $scope.colors = [{
            backgroundColor      :"#7EE4BE",
            hoverBackgroundColor :"#7EE4BE",
            borderColor          :"#7EE4BE",
            hoverBorderColor     :"#7EE4BE"
        }];
        $scope.labels = ["2011", "2012", "2013", "2014", "2015", "2016"];
        $scope.data = [
            [23, 26, 32, 30, 31, 35]
        ];

        $scope.onClick = function (points, evt) {
            console.log(points, evt);
        };

        $scope.options = {
            scales: {
                xAxes: [{
                    gridLines: {
                        display: false
                    }
                }],
                yAxes: [{
                    scaleShowLabels : false,
                    ticks: {
                        beginAtZero: true
                    },
                    display: true,
                    gridLines: {
                        display: true
                    },
                }]
            }
        };
    }

    function OHSStatistics($scope){
        // $scope.colors = ['#83D0EE'];
        $scope.colors = [{
            backgroundColor      :"#83D0EE",
            hoverBackgroundColor :"#83D0EE",
            borderColor          :"#83D0EE",
            hoverBorderColor     :"#83D0EE"
        }];
        $scope.labels = ["2011", "2012", "2013", "2014", "2015", "2016"];
        $scope.data = [
            [23, 26, 32, 30, 31, 35]
        ];

        $scope.onClick = function (points, evt) {
            console.log(points, evt);
        };

        $scope.options = {
            scales: {
                xAxes: [{
                    gridLines: {
                        display: false
                    }
                }],
                yAxes: [{
                    scaleShowLabels : false,
                    ticks: {
                        beginAtZero: true
                    },
                    display: true,
                    gridLines: {
                        display: true
                    },
                }]
            }
        };
    }

})();
