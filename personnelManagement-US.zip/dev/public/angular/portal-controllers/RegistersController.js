(function () {
    'use strict';

    angular
        .module('app')
        .controller('RegisterObservationsController', RegisterObservationsController)
        .controller('RegisterInspectionsController', RegisterInspectionsController)
        .controller('RegisterInspectionSummaryController', RegisterInspectionSummaryController)
        .controller('RegisterInspectionEntryController', RegisterInspectionEntryController)
        .controller('RegisterObservationEntryController', RegisterObservationEntryController)
        .controller('RegisterCorrectiveActionsController', RegisterCorrectiveActionsController)
        .controller('RegisterObservationEditController', RegisterObservationEditController)
        .controller('RegisterGreenhatController', RegisterGreenhatController)
        .controller('RegisterGreenhatCorrectiveController', RegisterGreenhatCorrectiveController)
        .controller('CorrectiveActionsStatisticsParticipation', CorrectiveActionsStatisticsParticipation)
        .controller('CorrectiveActionsStatisticsResults', CorrectiveActionsStatisticsResults)
        .controller('ObservationsRegisterStatistics', ObservationsRegisterStatistics)
        .controller('ObservationsRegisterResults1', ObservationsRegisterResults1)
        .controller('ObservationsRegisterResults2', ObservationsRegisterResults2)
        .controller('InspectionsRegisterStatistics', InspectionsRegisterStatistics)
        .controller('InspectionsRegisterResults', InspectionsRegisterResults)
        .controller('OnlineTrainingController', OnlineTrainingController);

    function RegisterObservationsController (
        ObservationService,
        $state,
        $scope,
        $localStorage,
        pieChartColor,
        dashboardChartOption
    ) {
        var observation = this;
        observation.chart = {};
        observation.charts = {};
        observation.list = [];
        observation.modalErrors = [];

        observation.exportCsv = exportCsv;

        init();

        function init()
        {
            ObservationService.getRegister().then(function (res) {
                observation.list = res.data.observations.data;
                observation.charts = res.data.charts.data;
                observation.chartOptions = dashboardChartOption;
                observation.pieColorClass = pieChartColor;
                console.log(observation.charts);
            });
        }

        function exportCsv()
        {
            console.log('export');

            observation.modalErrors = [];
            if(!observation.filter_from_date) {
                observation.modalErrors.push('From Date is required.');
            }

            if(!observation.filter_to_date) {
                observation.modalErrors.push('To Date is required.');
            }

            console.log(observation.modalErrors);

            if(observation.modalErrors.length > 0) {
                return false;
            }

            observation.filter_from_date = observation.filter_from_date.replace(/\//g, '-');
            observation.filter_to_date = observation.filter_to_date.replace(/\//g, '-');

            var location = 'export/company/' +
                $localStorage.currentUser.company.id_hash +
                '/csv/observation' +
                '?from=' +
                observation.filter_from_date +
                '&to=' + observation.filter_to_date;
            window.location = location;
        }
    }

    function RegisterObservationEditController (
        ObservationService,
        EmployeeService,
        $stateParams,
        $state,
        $scope
    ) {

        var observation = this;
        observation.view = {};
        observation.employees = [];
        observation.update = update;

        init();

        function init()
        {
            observation.config =
            {
                create: true,
                valueField: 'id',
                labelField: 'name',
                searchField: ['name'],
                maxItems: 1,
                onChange: function(value) {
                    console.log('onChange', value);
                    if(value) {
                        observation.view.performed_by_id = value;
                    }
                },
                onType: function(value) {
                    EmployeeService.search(value).then(function(res)
                    {
                        console.log(res);
                        observation.employees = res.data.employees.data;

                        if ($scope.$root.$$phase != '$apply' && $scope.$root.$$phase != '$digest') {
                            $scope.$apply();
                        }
                    });
                }
            };

            observation.observationByConfig =
            {
                create: true,
                valueField: 'id',
                labelField: 'name',
                searchField: ['name'],
                maxItems: 1,
                onChange: function(value) {
                    console.log('onChange', value);
                    if(value) {
                        observation.view.created_by_id = value;
                    }
                },
                onType: function(value) {
                    EmployeeService.search(value).then(function(res)
                    {
                        console.log(res);
                        observation.employees_observation_by = res.data.employees.data;

                        if ($scope.$root.$$phase != '$apply' && $scope.$root.$$phase != '$digest') {
                            $scope.$apply();
                        }
                    });
                }
            };

            ObservationService.getObservation($stateParams.id).then(function(res)
            {
                console.log(res);
                observation.view = res.data.observation.data;

                if(observation.view.inspector && typeof observation.view.inspector === 'object')
                {
                    observation.employees.push(observation.view.inspector);
                    observation.view.performed_by_id = observation.view.inspector.id;
                }

                if(observation.view.created_by && typeof observation.view.created_by === 'object')
                {
                    observation.employees_observation_by.push(observation.view.created_by);
                    observation.view.created_by_id = observation.view.created_by.id
                }

                setTimeout(function(){
                    var map = new google.maps.Map(document.getElementById('map'), {
                        zoom: 12,
                        center: {lat: 40.731, lng: -73.997}
                    });
                    var geocoder = new google.maps.Geocoder;
                    var infowindow = new google.maps.InfoWindow;
                    geocodeLatLng(geocoder, map, infowindow, observation.view.location);
                }, 1000);
            });
        }

        function update()
        {

            var formData = new FormData();

            formData.append('seen', observation.view.seen);

            formData.append('further_action', observation.view.further_action);
            formData.append('status', observation.view.status);
            formData.append('action_performed', observation.view.action_performed);
            formData.append('description', observation.view.description);
            formData.append('due', observation.view.due);

            if(observation.view.performed_by_id) {
                formData.append('performed_by', observation.view.performed_by_id);
            }

            if(observation.view.created_by_id) {
                formData.append('created_by', observation.view.created_by_id);
            }

            console.log(observation.view);
            ObservationService.update(
                observation.view.id,
                formData
            ).then(function(res) {
                $state.go('main.register.observation-entry', {id: observation.view.id});
            });
        }

        function geocodeLatLng(geocoder, map, infowindow, latLng) {
            var latlngStr = latLng.split(',', 2);
            var latlng = {lat: parseFloat(latlngStr[0]), lng: parseFloat(latlngStr[1])};
            geocoder.geocode({'location': latlng}, function(results, status) {
                if (status === 'OK') {
                    if (results[1]) {
                        console.log(results);
                        setTimeout(function(){
                            $(".classObservationAddress").text(results[1].formatted_address);
                        }, 200);
                        map.setZoom(11);
                        var marker = new google.maps.Marker({
                            position: latlng,
                            map: map
                        });
                        infowindow.setContent(results[1].formatted_address);
                        infowindow.open(map, marker);
                    } else {
                        window.alert('No results found');
                    }
                } else {
                    window.alert('Geocoder failed due to: ' + status);
                }
            });
        }
    }

    function RegisterObservationEntryController (
        ObservationService,
        $stateParams
    ) {

        var observation = this;
        observation.view = {};
        init();

        function init() {
            ObservationService.getObservation($stateParams.id).then(function(res) {
                console.log(res);
                observation.view = res.data.observation.data;

                setTimeout(function(){
                    console.log('llf');
                    var map = new google.maps.Map(document.getElementById('map'), {
                        zoom: 12,
                        center: {lat: 40.731, lng: -73.997}
                    });
                    var geocoder = new google.maps.Geocoder;
                    var infowindow = new google.maps.InfoWindow;
                    geocodeLatLng(geocoder, map, infowindow, observation.view.location);
                }, 1000);
            });
        }

        function geocodeLatLng(geocoder, map, infowindow, latLng) {
            var latlngStr = latLng.split(',', 2);
            var latlng = {lat: parseFloat(latlngStr[0]), lng: parseFloat(latlngStr[1])};
            geocoder.geocode({'location': latlng}, function(results, status) {
                if (status === 'OK') {
                    if (results[1]) {
                        console.log(results);
                        setTimeout(function(){
                            $(".classObservationAddress").text(results[1].formatted_address);
                        }, 200);
                        map.setZoom(11);
                        var marker = new google.maps.Marker({
                            position: latlng,
                            map: map
                        });
                        infowindow.setContent(results[1].formatted_address);
                        infowindow.open(map, marker);
                    } else {
                        window.alert('No results found');
                    }
                } else {
                    window.alert('Geocoder failed due to: ' + status);
                }
            });
        }
    }

    function RegisterInspectionsController (
        InspectionsService,
        dashboardChartOption,
        pieChartColor,
        $localStorage
    ) {
        var inspection = this;
        inspection.list = [];
        inspection.charts = {};
        inspection.modalErrors = [];

        inspection.exportCsv = exportCsv;
        init();

        function init() {
            InspectionsService.getRegister().then(function(res) {
                inspection.list = res.data.inspections.data;
                inspection.charts = res.data.charts.data;
                inspection.charts.pieColorClass = pieChartColor;
                inspection.barchartOption = dashboardChartOption;
            });
        }
        function exportCsv()
        {
            console.log('export');

            inspection.modalErrors = [];
            if(!inspection.filter_from_date) {
                inspection.modalErrors.push('From Date is required.');
            }

            if(!inspection.filter_to_date) {
                inspection.modalErrors.push('To Date is required.');
            }

            console.log(inspection.modalErrors);

            if(inspection.modalErrors.length > 0) {
                return false;
            }

            inspection.filter_from_date = inspection.filter_from_date.replace(/\//g, '-');
            inspection.filter_to_date = inspection.filter_to_date.replace(/\//g, '-');

            var location = 'export/company/' +
                $localStorage.currentUser.company.id_hash +
                '/csv/inspection' +
                '?from=' +
                inspection.filter_from_date +
                '&to=' + inspection.filter_to_date;
            window.location = location;
        }
    }

    function RegisterInspectionSummaryController (
        InspectionsService,
        $stateParams,
        $state
    ) {
        var inspection = this;
        inspection.list = [];
        inspection.view = {};

        init();

        function init()
        {
            InspectionsService.getInspection(
                $state.params.id
            ).then(function(res) {
                inspection.view = res.data.inspection.data;

                angular.forEach(inspection.view.items, function(i)
                {
                    if(i.description === null || i.description === 'null') {
                        inspection.view.description = '';
                    }
                });

            });
        }
    }

    function RegisterInspectionEntryController (
        InspectionsService,
        $state,
        $timeout,
        EmployeeService,
        $scope
    ) {
        var inspection = this;
        var _timeout;
        inspection.list = [];
        inspection.view = {};
        inspection.update = update;
        inspection.removeImage = removeImage;
        inspection.employees = [];

        init();

        inspection.config =
        {
            valueField: 'id',
            labelField: 'name',
            searchField: ['name'],
            maxItems: 1,
            onChange: function(value){
                inspection.view.assigned_to = value;
            },
            onType: function(value)
            {

                if(_timeout) {
                    $timeout.cancel(_timeout);
                }
                _timeout = $timeout(function()
                {
                    EmployeeService.search(
                        value
                    ).then(function(res) {
                        inspection.employees = res.data.employees.data;
                        if ($scope.$root.$$phase != '$apply' && $scope.$root.$$phase != '$digest') {
                            $scope.$apply();
                        }
                    });
                    _timeout = null;
                }, 900);

            }
        };

        function init()
        {
            InspectionsService.getInspectionItem(
                $state.params.id,
                $state.params.itemId
            ).then(function(res) {
                inspection.view = res.data.inspection_item.data;

                if(inspection.view.description === null || inspection.view.description === 'null') {
                    inspection.view.description = '';
                }

                if(inspection.view.required_action === null || inspection.view.required_action === 'null') {
                    inspection.view.required_action = '';
                }

                if(inspection.view.assigned_to) {
                    inspection.assignTo = inspection.view.assigned_to.id;
                    inspection.employees.push(inspection.view.assigned_to);
                }
            });
        }

        function update()
        {

            var formData = new FormData();
            var file = document.getElementById('inspectionPhoto').files[0];

            if(typeof file != 'undefined') {
                inspection.view.isRemoveImage = 0;
                formData.append('inspectionPhoto', file);
            }

            for(var i in inspection.view) {
                formData.append(i, inspection.view[i]);
            }

            InspectionsService.updateInspectionItem(
                inspection.view.inspection_id,
                inspection.view.id,
                formData
            ).then(function(res) {
                $state.go('main.register.inspection-summary', {id: inspection.view.inspection_id});
            });
        }

        function removeImage()
        {
            inspection.view.isRemoveImage = 1;
        }
    }

    function RegisterCorrectiveActionsController(
        $state,
        RegisterService,
        $localStorage,
        dashboardChartOption
    ) {

        var corrective         = this;

        corrective.open        = open;
        corrective.nextPage    = nextPage;
        corrective.prevPage    = prevPage;
        corrective.goPage      = goPage;
        corrective.exportCsv   = exportCsv;
        corrective.currentPage = 1;
        corrective.pagination  = {};

        init();

        function init()
        {
            action();
        }

        function action(params)
        {
            if(typeof params === 'undefined')
            {
                params = '';
            }

            RegisterService.getCorrectiveActions(
                params
            ).then(function(res) {
                corrective.pagination = res.data.corrective_actions.data;
                corrective.list = corrective.pagination.data;
                corrective.charts = res.data.charts.data;
                corrective.charts.option = dashboardChartOption;
            });
        }

        function nextPage()
        {
            if(corrective.currentPage >=
                corrective.pagination.last_page
            ) {
                return false;
            }

            corrective.currentPage++;
            action('?page='+corrective.currentPage);
        }

        function prevPage()
        {
            if(corrective.currentPage <= 1) {
                return false;
            }

            corrective.currentPage--;
            action('?page='+corrective.currentPage);
        }

        function goPage(page)
        {
            corrective.currentPage = page;
            action('?page='+corrective.currentPage);
        }

        function open(item)
        {
            switch(item.type.text)
            {
                case 'inspection': {
                    $state.go('main.register.inspection-entry', {
                        id: item.inspection_item.inspection_id,
                        itemId: item.inspection_item.id
                    });
                    } break;
                case 'observation':{
                    $state.go('main.register.observation-entry', {
                        id: item.observation_id
                    });
                    } break;
            }
        }

        function exportCsv()
        {
            corrective.modalErrors = [];
            if(!corrective.filter_from_date) {
                corrective.modalErrors.push('From Date is required.');
            }

            if(!corrective.filter_to_date) {
                corrective.modalErrors.push('To Date is required.');
            }

            if(corrective.modalErrors.length > 0) {
                return false;
            }

            corrective.filter_from_date = corrective.filter_from_date.replace(/\//g, '-');
            corrective.filter_to_date = corrective.filter_to_date.replace(/\//g, '-');

            var location = 'export/company/' +
                $localStorage.currentUser.company.id_hash +
                '/csv/corrective-actions' +
                '?from=' +
                corrective.filter_from_date +
                '&to=' + corrective.filter_to_date;
            window.location = location;
        }
    }

    function RegisterGreenhatController(
        $state,
        $localStorage,
        dashboardChartOption,
        pieChartColor,
        GreenhatService
    ) {
        var greenhat = this;

        greenhat.nextPage    = nextPage;
        greenhat.prevPage    = prevPage;
        greenhat.goPage      = goPage;
        greenhat.exportCsv   = exportCsv;

        greenhat.currentPage = 1;
        greenhat.pagination = {};
        greenhat.barChart = {};
        greenhat.pieChart = {};
        greenhat.charts = {
            pie:{open:0, closed: 0},
            bar:{
                mDirectSuperVisor: {yes:0, no:0},
                mHr : {yes:0, no:0},
                mContsManager : {yes:0, no:0},
                mPlantDept : {yes:0, no:0},
                mOhs : {yes:0, no:0},
                mEnviro : {yes:0, no:0}
            }
        };

        init();

        function init()
        {
            greenhat.barChart.data = [];
            greenhat.barChart.labels = ['SUPERVISOR', 'HR', 'CONST MGR', 'PLANT MGR', 'OHS MGR', 'ENVIRO MGR'];
            greenhat.barChart.chartOptions = dashboardChartOption;
            greenhat.barChart.color = ['#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F', '#023C6F'];
            greenhat.pieChart.data = [4, 5];
            greenhat.pieChart.labels = ['OPEN', 'CLOSED'];
            greenhat.pieColorClass = pieChartColor;
            action();
            console.log(greenhat.barChart.data);
        }

        function nextPage()
        {
            if(greenhat.currentPage >=
                greenhat.pagination.last_page
            ) {
                return false;
            }

            greenhat.currentPage++;
            action('?page='+greenhat.currentPage);
        }

        function prevPage()
        {
            if(greenhat.currentPage <= 1) {
                return false;
            }

            greenhat.currentPage--;
            action('?page='+greenhat.currentPage);
        }

        function goPage(page)
        {
            greenhat.currentPage = page;
            action('?page='+greenhat.currentPage);
        }

        function action(params = '')
        {
            console.log('ACTOINS');
            GreenhatService.getRegisteredService(
                params
            ).then(function(res) {
                greenhat.pagination = res.data.registered;
                processPrograms()
            }).catch(function(response) {

            });
        }

        function exportCsv()
        {
            console.log('export');
            console.log(greenhat.filter_from_date);

            greenhat.modalErrors = [];
            if(!greenhat.filter_from_date) {
                greenhat.modalErrors.push('From Date is required.');
            }

            if(!greenhat.filter_to_date) {
                greenhat.modalErrors.push('To Date is required.');
            }

            console.log(greenhat.modalErrors);

            if(greenhat.modalErrors.length > 0) {
                return false;
            }

            greenhat.filter_from_date = greenhat.filter_from_date.replace(/\//g, '-');
            greenhat.filter_to_date = greenhat.filter_to_date.replace(/\//g, '-');

            var location = 'export/company/' +
                $localStorage.currentUser.company.id_hash +
                '/csv/greenhat' +
                '?from=' +
                greenhat.filter_from_date +
                '&to=' + greenhat.filter_to_date;
            window.location = location;
        }

        function processPrograms()
        {
            angular.forEach(greenhat.pagination.data, function(program)
            {
                var hasAnyYes = false;
                var countYes = 0;
                var checkFeedBackTypes = {
                    'mDirectSuperVisor' : '-',
                    'mHr' : '-',
                    'mContsManager' : '-',
                    'mPlantDept' : '-',
                    'mOhs' : '-',
                    'mEnviro': '-'
                };

                for(var i in program.feedbacks)
                {
                    var feedback = program.feedbacks[i];
                    var field = '';
                    var output = '';
                    var form = JSON.parse(feedback.feedback);

                    switch(feedback.feedback_by)
                    {
                        case 2:
                            field = 'mDirectSuperVisor';
                            break;
                        case 3:
                            field = 'mHr';
                            break;
                        case 4:
                            field = 'mContsManager';
                            break;
                        case 5:
                            field = 'mPlantDept';
                            break;
                        case 6:
                            field = 'mOhs';
                      
                            break;
                        case 7:
                            field = 'mEnviro';

                            break;
                    }

                    if(field)
                    {
                        if(form.met_req) {
                            output = 'YES';
                            greenhat.charts.bar[field].yes++;
                            hasAnyYes = true;
                            countYes++;
                        } else if(!form.met_req) {
                            output = 'NO';
                            greenhat.charts.bar[field].no++;
                        }

                        checkFeedBackTypes[field] = output;
                    }
                }

                program['check_feedback_types'] = checkFeedBackTypes;

                if(countYes == 6) { greenhat.charts.pie.closed++; }
                if(hasAnyYes) { greenhat.charts.pie.open++; }

            });

            console.log('_________________');
            console.log(greenhat.pagination.data);
            greenhat.barChart.data = [
              greenhat.charts.bar.mDirectSuperVisor.yes,
              greenhat.charts.bar.mHr.yes,
              greenhat.charts.bar.mContsManager.yes,
              greenhat.charts.bar.mPlantDept.yes,
              greenhat.charts.bar.mOhs.yes,
              greenhat.charts.bar.mEnviro.yes
            ];
            greenhat.pieChart.data = [
              greenhat.charts.pie.open,
              greenhat.charts.pie.closed
            ]
        }
    }

    function RegisterGreenhatCorrectiveController(
        $localStorage,
        GreenhatService
    ) {
        var greenhat = this;
        greenhat.pagination = {};
        greenhat.nextPage    = nextPage;
        greenhat.prevPage    = prevPage;
        greenhat.goPage      = goPage;
        greenhat.exportCsv   = exportCsv;

        init();

        function init()
        {
            console.log('RegisterGreenhatCorrectiveController');
            action();
        }

        function action(params = '')
        {
            console.log('ACTOINS');
            console.log(params);

            GreenhatService.getRegisteredService(
                params
            ).then(function(res) {
                greenhat.pagination = res.data.registered;
               // processPrograms()
            }).catch(function(response) {

            });

        }

        function nextPage()
        {
            if(greenhat.pagination.current_page >=
                greenhat.pagination.last_page
            ) {
                return false;
            }

            greenhat.pagination.current_page++;
            action('?page='+greenhat.pagination.current_page);
        }

        function prevPage()
        {
            if(greenhat.pagination.current_page <= 1) {
                return false;
            }

            greenhat.pagination.current_page--;
            action('?page='+greenhat.pagination.current_page);
        }

        function goPage(page)
        {
            greenhat.pagination.current_page = page;
            action('?page='+greenhat.pagination.current_page);
        }

        function exportCsv()
        {
            console.log('export');
            console.log(greenhat.filter_from_date);

            greenhat.modalErrors = [];
            if(!greenhat.filter_from_date) {
                greenhat.modalErrors.push('From Date is required.');
            }

            if(!greenhat.filter_to_date) {
                greenhat.modalErrors.push('To Date is required.');
            }

            console.log(greenhat.modalErrors);

            if(greenhat.modalErrors.length > 0) {
                return false;
            }

            greenhat.filter_from_date = greenhat.filter_from_date.replace(/\//g, '-');
            greenhat.filter_to_date = greenhat.filter_to_date.replace(/\//g, '-');

            var location = 'export/company/' +
                $localStorage.currentUser.company.id_hash +
                '/csv/greenhat' +
                '?from=' +
                greenhat.filter_from_date +
                '&to=' + greenhat.filter_to_date;
            window.location = location;
        }
    }


    function OnlineTrainingController(
        RegisterService,
        barChartOption,
        $timeout,
        $localStorage
    ) {
        init();
        var vm = this;
        var _timeout;
        vm.search = search;
        vm.exportCsv = exportCsv;
        vm.nextPage = nextPage;
        vm.prevPage = prevPage;
        vm.goPage = goPage;
        vm.keyboards = '';
        vm.currentPage = 1;
        vm.pagination = {};

        function init()
        {
            console.log('OnlineTrainingController');
            RegisterService.getVideoCompletedTrainings(
                ''
            ).then(function(res) {
                vm.pagination = res.data.completed_trainings.data;
                vm.charts = res.data.charts.data;
                vm.barchartOption = barChartOption;
            });
        }

        function search(keywords)
        {
            if(_timeout) { // if there is already a timeout in process cancel it
                $timeout.cancel(_timeout);
            }
            _timeout = $timeout(function() {
                RegisterService.getVideoCompletedTrainings(
                    '?keywords=' + keywords
                ).then(function(res) {
                    vm.pagination = res.data.completed_trainings.data;
                });
                _timeout = null;
            }, 500);
        }

        function nextPage()
        {
            if(vm.currentPage >= vm.pagination.last_page) {
                return false;
            }

            vm.currentPage++;
            RegisterService.getVideoCompletedTrainings(
                '?page=' + vm.currentPage
            ).then(function(res) {
                vm.pagination = res.data.completed_trainings.data;
                vm.charts = res.data.charts.data;
                vm.barchartOption = barChartOption;
            });
        }

        function prevPage()
        {
            if(vm.currentPage <= 1) {
                return false;
            }

            vm.currentPage--;

            RegisterService.getVideoCompletedTrainings(
                '?page=' + vm.currentPage
            ).then(function(res) {
                vm.pagination = res.data.completed_trainings.data;
            });
        }

        function goPage(page) {

            vm.currentPage = page;

            RegisterService.getVideoCompletedTrainings(
                '?page=' + vm.currentPage
            ).then(function(res) {
                vm.pagination = res.data.completed_trainings.data;
            });
        }

        function exportCsv()
        {
            console.log('export');
            console.log(vm.filter_from_date);

            vm.modalErrors = [];
            if(!vm.filter_from_date) {
                vm.modalErrors.push('From Date is required.');
            }

            if(!vm.filter_to_date) {
                vm.modalErrors.push('To Date is required.');
            }

            console.log(vm.modalErrors);

            if(vm.modalErrors.length > 0) {
                return false;
            }

            vm.filter_from_date = vm.filter_from_date.replace(/\//g, '-');
            vm.filter_to_date = vm.filter_to_date.replace(/\//g, '-');

            var location = 'export/company/' +
                $localStorage.currentUser.company.id_hash +
                '/csv/online-training' +
                '?from=' +
                vm.filter_from_date +
                '&to=' + vm.filter_to_date;
            window.location = location;
        }
    }

    function CorrectiveActionsStatisticsParticipation($scope, $controller)
    {
        $scope.colors = [{
            backgroundColor      :"#157CC4",
            hoverBackgroundColor :"#157CC4",
            borderColor          :"#157CC4",
            hoverBorderColor     :"#157CC4"
        }];
        $scope.labels = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
        $scope.data = [
            [58, 18, 24, 37, 28, 35, 25, 31, 37, 21, 21, 27]
        ];

        $scope.onClick = function (points, evt) {
            console.log(points, evt);
        };

    }

    function CorrectiveActionsStatisticsResults($scope, $controller)
    {
        $scope.colors = ["#E97472", "#F29B50", "#63C169", "#83D0EE"];
        $scope.labels = ['OVERDUE - 100', 'IN PROGRESS - 250', 'OPEN - 250', 'CLOSED - 300'];
        $scope.data = [100, 250, 250, 300];
        $scope.options = {
            legend:
            {
                display: true,
                position: 'right',
            }
        };
        $scope.dataset = {
            borderWidth: 0
        };
    }

    function ObservationsRegisterStatistics($scope, $controller)
    {
        $scope.colors = [{
            backgroundColor      :"#023C6F",
            hoverBackgroundColor :"#023C6F",
            borderColor          :"#023C6F",
            hoverBorderColor     :"#023C6F"
        }];
        $scope.labels = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
        $scope.data = [
            [48, 18, 24, 37, 28, 35, 25, 31, 37, 21, 21, 27]
        ];

        $scope.onClick = function (points, evt) {
            console.log(points, evt);
        };

        // $scope.datasetOverride = [{ yAxisID: 'y-axis-1' }];
        $scope.options = {
            scales: {
                xAxes: [{
                    gridLines: {
                        display: false
                    }
                }],
                yAxes: [{
                    scaleShowLabels : false,
                    ticks: {
                        beginAtZero: true,
                        stepSize: 1
                    },
                    display: true,
                    gridLines: {
                        display: true,
                        offsetGridLines: false
                    },
                }]
            }
        };
    }

    function ObservationsRegisterResults1($scope, $controller)
    {
        $scope.colors = ["#868E90", "#157CC4"];
        $scope.labels = ['PPE - 2', 'PLANT - 27'];
        $scope.data = [2, 27];
        $scope.options = {
            legend:
            {
                display: true,
                position: 'bottom',
            }
        };
        $scope.dataset = {
            borderWidth: 0
        };
    }

    function ObservationsRegisterResults2($scope, $controller)
    {
        $scope.colors = ["#319A39", "#CF2A27"];
        $scope.labels = ['POSITIVE - 2', 'NEGATIVE - 27'];
        $scope.data = [2, 27];
        $scope.options = {
            legend:
            {
                display: true,
                position: 'bottom',
                // labels: {
                //     fontColor: ["#E97472", "#F29B50", "#63C169", "#63C169"],
                //     generateLabels: function(chart) {
                //         console.log(chart);
                //     }
                // }
            }
        };
        $scope.dataset = {
            borderWidth: 0
        };
    }

    function InspectionsRegisterStatistics($scope, $controller)
    {
        $scope.colors = [{
            backgroundColor      :"#023C6F",
            hoverBackgroundColor :"#023C6F",
            borderColor          :"#023C6F",
            hoverBorderColor     :"#023C6F"
        }];
        $scope.labels = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
        $scope.data = [
            [28, 18, 24, 37, 28, 35, 25, 31, 37, 21, 21, 27]
        ];

        $scope.onClick = function (points, evt) {
            console.log(points, evt);
        };

        // $scope.datasetOverride = [{ yAxisID: 'y-axis-1' }];
        $scope.options = {
            scales: {
                xAxes: [{
                    gridLines: {
                        display: false
                    }
                }],
                yAxes: [{
                    scaleShowLabels : false,
                    ticks: {
                        beginAtZero: true,
                        stepSize: 1
                    },
                    display: true,
                    gridLines: {
                        display: true,
                        offsetGridLines: false
                    },
                }]
            }
        };
    }

    function InspectionsRegisterResults($scope, $controller)
    {
        $scope.colors = ["#CF2A27", "#319A39"];
        $scope.labels = ['POSITIVE - 2', 'NEGATIVE - 129'];
        $scope.data = [2, 129];
        $scope.options = {
            legend:
            {
                display: true,
                position: 'right',
                // labels: {
                //     fontColor: ["#E97472", "#F29B50", "#63C169", "#63C169"],
                //     generateLabels: function(chart) {
                //         console.log(chart);
                //     }
                // }
            }
        };
        $scope.dataset = {
            borderWidth: 0
        };
    }

})();
