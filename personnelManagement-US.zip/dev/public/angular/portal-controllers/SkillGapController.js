(function () {
    'use strict';

    angular
        .module('app')
        .controller('SkillGapController', Controller);
    function Controller(
        SkillGapService,
        $state,
        $stateParams,
        $localStorage,
        $scope,
        pieChartColor,
        dashboardChartOption
    ) {
      var skillGap = this;
      skillGap.list = [];
      skillGap.chart = {};
      skillGap.pie = {};
      skillGap.exportCsv = exportCsv;
      skillGap.modalErrors = [];
      skillGap.exportType = '';

      init();

      function init() {
        SkillGapService.list().then(function(res) {
          console.log(res);
          var data = [];

          skillGap.pie.labels = ['SKILLS GAP', 'SKILLED'];
          skillGap.pieColorClass = pieChartColor;
          skillGap.chart.options = dashboardChartOption;
          skillGap.list = res.data.analytics.data.employees;

          skillGap.pie.data = [res.data.analytics.data.graph.skills_gap, res.data.analytics.data.graph.skilled];

          angular.forEach(res.data.analytics.data.graph.monthly_skilled, function(value, key) {
    					this.push(value);
    			}, data);
          skillGap.chart = res.data.analytics.data.charts;
          skillGap.chart.data = data;
          skillGap.chart.option = dashboardChartOption;
        });
      }

      function exportCsv() {
        skillGap.modalErrors = [];
        if(!skillGap.filter_from_date) {
            skillGap.modalErrors.push('From Date is required.');
        }

        if(!skillGap.filter_to_date) {
            skillGap.modalErrors.push('To Date is required.');
        }

        console.log(skillGap.modalErrors);

        if(skillGap.modalErrors.length > 0) {
            return false;
        }

        skillGap.filter_from_date = skillGap.filter_from_date.replace(/\//g, '-');
        skillGap.filter_to_date = skillGap.filter_to_date.replace(/\//g, '-');

        var target = skillGap.exportType == 'employee' ? 'skillsgap-by-employee' : 'skillsgap-by-month';

        var location = 'export/company/' +
          $localStorage.currentUser.company.id_hash +
          '/csv/' + target +
          '?from=' +
          skillGap.filter_from_date +
          '&to=' + skillGap.filter_to_date;

        window.location = location;
      }
    }

})();
