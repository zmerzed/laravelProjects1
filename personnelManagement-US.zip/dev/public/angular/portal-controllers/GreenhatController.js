// (function () {
// 		'use-strict';
//
// 		angular
// 				.module('app')
// 				.controller('GreenhatController', Controller)
// 				.controller('EnrollmentProgramController', EnrollmentProgramController);
//
// 		function GreenhatController() {
// 			console.log('GreenhatController');
// 			var greenhatMain = this;
// 		}
//
// 		function EnrollmentProgramController(
// 			EmployeeService,
// 			CompanyService,
// 			$stateParams
// 		) {
//
// 			var greenhatEnrollment = this;
// 			greenhatEnrollment.view = false;
//
// 		}
//
//
//
// })();
