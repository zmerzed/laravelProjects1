(function () {
    'use strict';

    angular
        .module('app')
        .controller('InspectionsListController', InspectionsListController)
        .controller('InspectionsViewController', InspectionsViewController)
        .controller('InspectionsCreateController', InspectionsCreateController)
        .controller('InspectionsSummaryController', InspectionsSummaryController);

    function InspectionsListController(
        InspectionsService,
        $state,
        $scope
    ) {

        var inspectionsList = this;

        inspectionsList.add = add;
        inspectionsList.select = select;
        inspectionsList.update = update;

        inspectionsList.view = {};
        inspectionsList.categories = [];
        inspectionsList.itemCategories = [];
        inspectionsList.inspection_options = [];
        inspectionsList.list = [];
        inspectionsList.new = {};
        inspectionsList.new.items = [{}];

        init();

        function init()
        {
            InspectionsService.getCategories().then(function(res)
            {
                inspectionsList.categories = res.data.categories.data;
                inspectionsList.itemCategories = res.data.item_categories.data;
                inspectionsList.inspection_options = res.data.inspection_options.data;
                inspectionsList.list = res.data.inspections.data;
            });

            inspectionsList.newConfig =
            {
                valueField: 'id',
                labelField: 'name',
                maxItems:1,
                searchField: ['name'],
                onChange: function(value)
                {
                    if(value < 0)
                    {
                        var name = prompt("Enter a new category");

                        if(!name)
                        {
                            alert("Empty Category name");
                            this.clear();
                        } else {
                            InspectionsService.addItemCategory(
                                {name: name}
                            ).then(function(res) {
                                var newCategory = res.data.new_item_category.data;
                                inspectionsList.new.items[0].inspection_item_category_id = newCategory.id;
                                inspectionsList.itemCategories.unshift(newCategory);
                            });
                        }
                    }
                }
            };
        }

        function select(ins)
        {
            inspectionsList.view = ins;
        }

        function update()
        {
            InspectionsService.updateInspection(
                inspectionsList.view.id,
                inspectionsList.view
            ).then(function(res) {
                $state.reload();
            });
        }

        function add()
        {

            inspectionsList.new.itemCategories = inspectionsList.itemCategories;
            inspectionsList.new.itemOptions = inspectionsList.inspection_options;

            if(!inspectionsList.new.items[0].name) {
                alert("Inspection name is empty");
                return false;
            }

            if(!inspectionsList.new.items[0].options) {
                alert("Please select a option");
                return false;
            }

            if(!inspectionsList.new.items[0].inspection_item_category_id)
            {
                alert("Please select an item category");
                return false;
            }

            $state.go(
                'main.inspections.create',
                { newInspection: inspectionsList.new }
            );
        }
    }

    function InspectionsCreateController(
        InspectionsService,
        $state,
        $stateParams,
        $scope
    ) {
        var inspectionCreate = this;
        inspectionCreate.finalize = finalize;
        inspectionCreate.cancel = cancel;
        inspectionCreate.create = create;
        inspectionCreate.add = add;
        inspectionCreate.view = view;
        inspectionCreate.update = update;
        inspectionCreate.finalize = finalize;
        inspectionCreate.getCategoryName = getCategoryName;

        inspectionCreate.new = {};
        inspectionCreate.newItem = {};
        inspectionCreate.formStatus = 'create';

        init();

        function init()
        {
            if(
                !$stateParams.newInspection
            //&& (!$stateParams.newInspection.itemCategories && $stateParams.newInspection.itemOptions)
            ) {
                $state.go('main.inspections.list');
            }

            inspectionCreate.new = $stateParams.newInspection;

            for(var i=0; i<inspectionCreate.new.items.length; i++)
            {
                var item = inspectionCreate.new.items[i];

                for(var x=0; x<inspectionCreate.new.itemCategories.length; x++)
                {
                    var cat = inspectionCreate.new.itemCategories[x];

                    if(item.inspection_item_category_id == cat.id)
                    {
                        item.itemCategorySelected = cat;
                        break;
                    }
                }
            }


            inspectionCreate.newConfig = {
                valueField: 'id',
                labelField: 'name',
                maxItems:1,
                searchField: ['name'],
                onChange: function(value){

                    if(value < 0)
                    {
                        var name = prompt("Enter a new category");

                        if(!name)
                        {
                            alert("Empty Category name");
                            this.clear();
                        } else {
                            InspectionsService.addItemCategory(
                                {name: name}
                            ).then(function(res) {
                                var newCategory = res.data.new_item_category.data;
                                inspectionCreate.newItem.inspection_item_category_id = newCategory.id;
                                inspectionCreate.new.itemCategories.unshift(newCategory);
                            });
                        }
                    }
                },
                onType: function(value) {

                }
            };
        }

        function finalize()
        {
            InspectionsService.addInspection(
                inspectionCreate.new
            ).then(function(res) {
                $state.go('main.inspections.list');
            }).catch( function(res) {
                $scope.showToastr('error', res.data.message);
            });
        }

        function view(item)
        {
            clearModalForm();
            $('#idNew').modal('show');
            inspectionCreate.formStatus = 'update';
            inspectionCreate.newItem = item;

        }

        function getCategoryName(itemId)
        {
            for(var i in inspectionCreate.new.itemCategories)
            {
                var item = inspectionCreate.new.itemCategories[i];
                if(itemId == item.id)
                {
                    return item.name;
                }
            }

            return '';
        }

        function create()
        {
            clearModalForm();
            $('#idNew').modal('show');
            inspectionCreate.formStatus = 'create';
        }

        function add()
        {

            if(!inspectionCreate.newItem.name) {
                alert("Inspection name is empty");
                return false;
            }

            if(!inspectionCreate.newItem.options) {
                alert("Please select a option");
                return false;
            }

            if(!inspectionCreate.newItem.inspection_item_category_id)
            {
                alert("Please select an item category");
                return false;
            }

            var item = angular.copy(inspectionCreate.newItem);

            inspectionCreate.new.items.push(item);
            clearModalForm();
        }

        function update()
        {

            if(!inspectionCreate.newItem.name) {
                alert("Inspection name is empty");
                return false;
            }

            if(!inspectionCreate.newItem.options) {
                alert("Please select a option");
                return false;
            }

            if(!inspectionCreate.newItem.inspection_item_category_id)
            {
                alert("Please select an item category");
                return false;
            }

            clearModalForm();
        }

        function cancel()
        {
            $state.go('main.inspections.list');
        }

        function clearModalForm()
        {
            inspectionCreate.newItem = {};
            $('#idNew').modal('hide');
        }

        $scope.$watch('inspectionCreate.newItem.itemCategorySelected', function(cat)
        {

            if(cat && cat.name == 'Other/Add')
            {
                delete inspectionCreate.newItem.itemCategorySelected;

                var name = prompt("Enter a new category")

                if(!name)
                {
                    alert("Empty Category name");
                    return false;
                }

                InspectionsService.addItemCategory(
                    {name: name}
                ).then(function(res) {
                    var newCategory = res.data.new_item_category.data;
                    inspectionCreate.newItem.itemCategorySelected = newCategory;
                    inspectionCreate.new.itemCategories.unshift(newCategory);
                });
            }
        });

    }

    function InspectionsViewController (
        InspectionsService,
        $state,
        $stateParams,
        $scope
    ) {

        var inspectionsView = this;

        inspectionsView.addTrigger = addTrigger;
        inspectionsView.add = add;
        inspectionsView.remove = remove;
        inspectionsView.viewItem = viewItem;
        inspectionsView.deleteItem = deleteItem;
        inspectionsView.updateItem = updateItem;
        inspectionsView.getCategoryName = getCategoryName;
        inspectionsView.popup = 0;
        inspectionsView.list = {};
        inspectionsView.items = [];
        inspectionsView.itemCategories = [];
        inspectionsView.inspection_options = [];
        inspectionsView.update = {};
        inspectionsView.update.items = [{}];
        inspectionsView.itemData = {};
        inspectionsView.isFinalize = false;
        inspectionsView.newItem = {};

        init();

        function init()
        {
            if($state.params.isFinalize)
            {
                inspectionsView.isFinalize = true;
            }

            InspectionsService.getCategories().then(function(res) {
                inspectionsView.itemCategories = res.data.item_categories.data;
                inspectionsView.inspection_options = res.data.inspection_options.data;
                console.log(inspectionsView.itemCategories);
            });

            InspectionsService.getInspectionList($stateParams.id).then(function(res)
            {
                inspectionsView.list = res.data.inspection.data;
                inspectionsView.items = res.data.inspection.data.items;
            }).catch(function(res){});


            inspectionsView.newConfig =
            {
                valueField: 'id',
                labelField: 'name',
                maxItems:1,
                searchField: ['name'],
                onChange: function(value)
                {

                    if(value < 0)
                    {
                        var name = prompt("Enter a new category");

                        if(!name)
                        {
                            alert("Empty Category name");
                            this.clear();
                        } else {
                            InspectionsService.addItemCategory(
                                {name: name}
                            ).then(function(res) {
                                var newCategory = res.data.new_item_category.data;
                                inspectionsView.newItem.inspection_item_category_id = newCategory.id;
                                inspectionsView.itemCategories.unshift(newCategory);
                            });
                        }
                    }
                }
            };

            inspectionsView.updateConfig =
            {
                valueField: 'id',
                labelField: 'name',
                maxItems:1,
                searchField: ['name'],
                onChange: function(value)
                {

                    if(value < 0)
                    {
                        var name = prompt("Enter a new category");

                        if(!name)
                        {
                            alert("Empty Category name");
                            this.clear();
                        } else {
                            InspectionsService.addItemCategory(
                                {name: name}
                            ).then(function(res) {
                                var newCategory = res.data.new_item_category.data;
                                inspectionsView.itemData.inspection_item_category_id = newCategory.id;
                                inspectionsView.itemCategories.unshift(newCategory);
                            });
                        }
                    }
                }
            };
        }

        function addTrigger()
        {
            inspectionsView.popup = 1;
            inspectionsView.itemData = {}
        }

        function getCategoryName(itemId)
        {
            for(var i in inspectionsView.itemCategories)
            {
                var item = inspectionsView.itemCategories[i];
                if(itemId == item.id)
                {
                    return item.name;
                }
            }

            return '';
        }

        function add()
        {

            if(!validate(inspectionsView.newItem)) {
                return false;
            }

            $('.bs-example-modal-lg').modal('hide');

            InspectionsService.addInspectionItem(
                $stateParams.id,
                inspectionsView.newItem
            ).then(function(res) {

                $state.reload($state.$current.self.name);
            }).catch( function(res) {
                $scope.showToastr('error', res.data.message);
            });
        }

        function remove()
        {
            InspectionsService.removeInspection(
                $stateParams.id
            ).then(function() {
                $state.go('main.inspections.list');
            });
        }

        function viewItem(item)
        {
            if(item.not_applicable == 1) {
                item.not_applicable = true
            }
            delete inspectionsView.itemData;
            inspectionsView.itemData = angular.copy(item);
            inspectionsView.popup = 2;
        }

        function deleteItem(item)
        {
            InspectionsService.deleteItem(
                $stateParams.id,
                item.id
            ).then(function(res) {
                $state.reload('main.inspections.view', {id: $stateParams.id});
            })
        }

        function updateItem(item)
        {
            if(!validate(item)) {
                return false;
            }

            $('.bs-example-modal-lg').modal('hide');

            var formData = new FormData();

            for(var i in item) {
                formData.append(i, item[i]);
            }

            InspectionsService.updateInspectionItem(
                $stateParams.id,
                inspectionsView.itemData.id,
                formData
            ).then(function(res) {
                $state.reload($state.$current.self.name);
            });
        }

        function validate(item)
        {

            if(!item.name) {
                alert("Inspection name is empty");
                return false;
            }

            if(!item.options) {
                alert("Please select a option");
                return false;
            }

            if(!item.inspection_item_category_id)
            {
                alert("Please select an item category");
                return false;
            }

            return true;
        }

    }

    function InspectionsSummaryController (
        InspectionsService,
        $stateParams
    ) {

        var inspectionsSummary = this;

        inspectionsSummary.list = {};
        inspectionsSummary.items = [];
        inspectionsSummary.items.option_btn = [];

        inspectionsSummary.itemCategories = [];
        inspectionsSummary.inspection_options_btn = [];
        inspectionsSummary.inspection_options = [];

        init();

        function init() {
            InspectionsService.getCategories().then(function(res) {
                inspectionsSummary.itemCategories = res.data.item_categories.data;
                inspectionsSummary.inspection_options = res.data.inspection_options.data;
                inspectionsSummary.inspection_options_btn = res.data.inspection_options_btn.data;
            });

            InspectionsService.getInspectionList($stateParams.id).then(function(res){

                inspectionsSummary.list = res.data.inspection.data;
                inspectionsSummary.items = res.data.inspection.data.items;

                for(var x in inspectionsSummary.items) {
                    inspectionsSummary.items.option_btn = inspectionsSummary.inspection_options_btn[inspectionsSummary.items[x].options];
                }
            }).catch(function(res){

            } );
        }

        function summary() {

        }
    }
})();
