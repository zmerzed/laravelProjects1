(function () {
	'use strict';

	angular
		.module('app')
		.controller('GreenhatController', GreenhatController);

	function GreenhatController(
		GreenhatService,
		$scope,
		$stateParams,
		$localStorage,
		$window
	) {
		var greenhat = this;

		greenhat.submitFeedback = submitFeedback;
		greenhat.feedback = {};
		
		init();

		function init()
		{
			console.log("CHECKKKKKKINGGG");

			var formData = new FormData();

			formData.append('greenhat_program_id', $stateParams.hashId);
			formData.append('user_id', $localStorage.currentUser.user.user_id);

			GreenhatService.checkFeedback(formData).then(function(res)
			{
				console.log(res);
				if( res.data.feedback ){
					greenhat.feedback = JSON.parse(res.data.feedback.data.feedback);
					greenhat.program = res.data.program.data;
				}else{
					greenhat.feedback = {};
					greenhat.program = res.data.program.data;
				}

			}).catch(function(res){

				toastr['error']('Something went wrong. Please contact system administrator.');
			})
		}

		function submitFeedback()
		{
			var formData = new FormData();
			greenhat.feedback.respond = true;
			formData.append('user_id', $localStorage.currentUser.user.user_id);
			formData.append('greenhat_program_id', $stateParams.hashId);
			formData.append('feedback', JSON.stringify(greenhat.feedback));

			GreenhatService.submitFeedback(
				formData
			).then(function(res) {

				if(res.data.result){
					toastr['success']('Successfully added feedback.');

					$window.location.href = App.url;
				}else{
					toastr['error']('Something went wrong. Please contact system administrator.');
				}

			}).catch(function(res){
				toastr['error']('Something went wrong. Please contact system administrator.');
			})
		}

	}
})();
