(function () {
    'use strict';

    angular
        .module('app')
        .service('UserService', Service);

    function Service(
        $http,
        baseUrl
    ) {
        var service = {};
        service.search = search;
        service.add = add;
        service.remove = remove;
        service.view = view;
        service.resetPassword = resetPassword;
        
        return service;

        function search(params)
        {
            return $http.get(baseUrl.helix_admin + '/user/lists' + params);
        }
        
        function add(formData)
        {
            return $http.post(baseUrl.helix_admin + '/user/add', formData, {headers: {'Content-Type': undefined, 'Process-Data':false}});
        }

        function remove(id)
        {
            return $http.post(baseUrl.helix_admin + '/user/' + id + '/delete');
        }

        function view(id)
        {
            return $http.get(baseUrl.helix_admin + '/user/' + id + '/view');
        }

        function resetPassword(id)
        {
            return $http.get(baseUrl.helix_admin + '/user/' + id + '/reset_password');
        }
    }
})();
