(function () {
    'use strict';

    angular
        .module('app')
        .factory('CompanyService', Service);

    function Service(
        $http,
        baseUrl
    ) {
        var service = {};
        service.search = search;
        service.getLogs = getLogs;

        return service;

        function search(params)
        {
            return $http.get(baseUrl.helix_admin + '/company/lists' + params);
        }
        
        function getLogs(companyId, params)
        {
            return $http.get(baseUrl.helix_admin + '/company/' + companyId + '/logs' + params);
        }
    }
})();
