<?php

use Illuminate\Database\Seeder;

class HelixUsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        $date_time = new \DateTime();
//        DB::table('helix_users')->insert(
//            ['first_name' => 'john', 'last_name' => 'doe', 'mobile' => '0491 570 156', 'user_id' => 1, 'role_id' => 1, 'created_at' => $date_time, 'updated_at' => $date_time]
//        );
    }
}
